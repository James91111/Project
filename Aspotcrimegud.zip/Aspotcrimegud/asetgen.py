#!/usr/bin/env python3
# ============================================================
#  ASETGEN — paket dikirim TANPA PNG; saat pertama dijalankan,
#  engine merender sendiri semua aset latar/furnitur/objek
#  (prosedural, deterministik). Sekali saja, +-1 menit.
# ============================================================
import os

HERE = os.path.dirname(os.path.abspath(__file__))
AD = os.path.join(HERE, 'assets')

def _kurang(sub, min_n):
    d = os.path.join(AD, sub)
    if not os.path.isdir(d):
        return True
    return len([f for f in os.listdir(d) if f.endswith('.png')]) < min_n

def ensure(log=print):
    kerja = False
    if _kurang('bgpack', 100):
        kerja = True; log('  [aset] render 100+ resep latar (bgpack, per potongan)...')
        import bgpack, subprocess, sys
        n = len(bgpack.RECIPES)
        for a in range(0, n, 60):                # subprocess = memori lepas per potongan
            subprocess.run([sys.executable, 'bgpack.py', '--from', str(a),
                            '--to', str(min(n, a + 60))], check=True,
                           cwd=os.path.dirname(os.path.abspath(__file__)))
    if _kurang('furnipack', 100):
        kerja = True; log('  [aset] render furnitur (furnigen)...')
        import furnigen; furnigen.main()
    if _kurang('objpack', 100):
        kerja = True; log('  [aset] render objek (objpack)...')
        import objpack; objpack.main()
    if _kurang('vpackbg', 500):
        kerja = True; log('  [aset] render 500 pratinjau latar template (vpack)... +-30 dtk')
        import vpack; vpack.ensure_bgpreviews()
    if kerja:
        log('  [aset] semua aset siap.')

if __name__ == '__main__':
    ensure()
