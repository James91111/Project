#!/usr/bin/env python3
# ============================================================
#  STUDIO — satu pintu masuk: pasang dependensi (sekali),
#  generate aset prosedural (sekali), lalu buka UI web lengkap.
#  Pakai:  python3 studio.py --port 8808
# ============================================================
import os, sys, subprocess, runpy

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)

try:
    import flask, PIL, edge_tts, numpy, soundfile, imageio_ffmpeg  # noqa
except ImportError:
    print('  Memasang komponen (sekali saja, butuh internet)...')
    subprocess.call([sys.executable, '-m', 'pip', 'install', '-q',
                     'flask', 'pillow', 'edge-tts', 'numpy', 'soundfile', 'imageio-ffmpeg'])

runpy.run_path(os.path.join(HERE, 'a2studio.py'), run_name='__main__')
