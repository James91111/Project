#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
python3 studio.py &
sleep 4
(command -v xdg-open >/dev/null && xdg-open http://localhost:8808) || \
(command -v python3 >/dev/null && python3 -m webbrowser http://localhost:8808)
wait
