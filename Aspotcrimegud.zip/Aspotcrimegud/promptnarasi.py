#!/usr/bin/env python3
# ============================================================
#  PROMPT NARASI — SUB-HALAMAN BARU Spot The Scam Studio
#  ------------------------------------------------------------
#  FILE BARU: a2studio.py / studio.py / file lama TIDAK diubah.
#  Jalankan :  python promptnarasi.py --port 8808
#              (atau klik  studio-narasi.sh)
#  Studio utama tetap di   :  http://localhost:8808/
#  Sub-halaman prompt      :  http://localhost:8808/narasi
# ============================================================
import os, sys, re, json, time, random, socket, shutil, subprocess, threading

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

DRIVE      = os.path.join(BASE, 'drive')
IDEAS_FILE = os.path.join(DRIVE, 'ide_episoda.txt')
LOG_FILE   = os.path.join(DRIVE, 'narasi_log.json')
os.makedirs(DRIVE, exist_ok=True)

# ============================================================
#  VARIATION DECK — sumber keunikan tiap episode
# ============================================================
DECK = {
    "FORMAT": [
        "COUNTDOWN: several scams from my facts, ranked from mildest to most shocking, biggest shock last",
        "STORY FIRST: tell one victim's full story in order, then break it down into red flags the viewer can learn",
        "DEEP DIVE: dissect ONE scam step by step, from first contact to final loss, told as a timeline",
        "ALERT MODE: urgent briefing about one scam spreading right now, the fastest-paced episode type",
        "MYTH BUSTING: take common beliefs about this scam and prove each one wrong, one by one",
        "RECOVERY MODE: the viewer already sent money; structure it as the first 24 hours, what to do step by step",
        "SIDE BY SIDE: two similar cases from my facts, told in parallel, and the one difference that changed the outcome",
        "MAILBAG: answer specific viewer questions about this scam, one question at a time",
    ],
    "COLD OPEN": [
        "BIGGEST NUMBER: the most shocking stat plus an unexpected place or moment",
        "MID ACTION: start inside the scene, the phone already ringing, no explanation yet",
        "ORDINARY DAY: a quiet morning routine, then the moment everything changes",
        "WOULD YOU: one direct question to the viewer that they will honestly answer as they watch",
        "TWO NEIGHBORS: the same scam hit two people, one lost everything and one lost nothing, promise to explain why",
        "END FIRST: reveal the loss in sentence one, then rewind to how it started",
        "TICKING CLOCK: frame the episode as a race against time",
        "SMALL DETAIL: one tiny odd detail the victim almost ignored, and it turns out to be the key",
    ],
    "VOICE": [
        "warm neighbor who knows everyone on the block, gentle but firm",
        "retired fraud investigator, calm, dry, practical, zero drama",
        "an adult child talking to their own parent, loving and slightly worried",
        "local news anchor energy, urgent but simple, no jargon",
        "patient teacher who explains slowly and repeats the important part once",
        "sharp grandmother who already outsmarted two scammers and is a little proud of it",
    ],
    "RHYTHM": [
        "short staccato sentences in action scenes, longer flowing sentences in explanations",
        "alternate one long sentence with two short ones throughout the episode",
        "story flows naturally, but every THE FIX lands as one punchy short sentence",
        "ultra-short sentences throughout, almost like a heartbeat",
    ],
    "TRANSITIONS": [
        "every transition is a question the viewer is thinking right now",
        "time markers: later that day, the next morning, three days pass",
        "sound moments: the phone, the knock, the notification ping described in words",
        "but-pivots: every turn begins with but or however",
        "direct-address pauses: here is where it turns / and this is the part most people miss",
    ],
    "PAYOFF": [
        "one golden rule that kills every scam in this episode",
        "a three-word rule the viewer can repeat out loud",
        "the one move: every scam needs the victim to make one move, remove the move and the scam dies",
        "a two-question test to run before sending money or information anywhere",
        "the door rule: trust only contact that you started yourself",
    ],
    "CTA": [
        "soft family angle: if someone you love needs the next part, subscribe now",
        "community roll call: comment which item number you have seen, your comment may save someone",
        "next-episode tease: say exactly what is coming next and invite them to be there",
        "mission statement: one honest sentence about why this channel exists",
        "send-it challenge: ask the viewer to send this video to one specific person today",
    ],
    "WORLD": [

        "AUTHORITY VISIT: weave in one scene where an FBI agent (jacket says FBI) or a sheriff with a POLICE car knocks and explains one safety rule",
        "COURIER WATCH: weave in one scene with a courier at the door holding a box or an envelope, and the victim wisely does not hand it over",
        "BANK COUNTER: weave in one scene at a bank branch where a teller or the fraud department slows the transfer and asks one kind question",
        "SCREEN TROUBLE: weave in one scene where a computer screen freezes with a loud pop-up alarm, and the victim never calls the number on it",
        "MAILBOX MOMENT: weave in one scene with a mailbox, a letter, or an envelope carrying a fake invoice or a fake check",
        "GOLD WARNING: weave in one scene about a box of gold bars and a stranger who wants it collected at the door",
        "GIFT CARD TRAP: weave in one scene at a store shelf with gift cards, and the victim walks away after remembering the rule",
        "KITCHEN TABLE: weave in one warm scene at a kitchen table with tea where the family agrees on a safe word",
        "CHART NUMBERS: weave in one scene where an agent points at a chart or a map of the states while the loss numbers climb",
        "PHONE FIRST: weave in one scene where the phone rings on the counter during breakfast and the caller id looks real",
        "HOSPITAL REAL: if and only if a person is truly hurt, one brief hospital scene with a doctor; a sick computer is NEVER a hospital",
        "NEIGHBOR SAVES: weave in one scene where a neighbor or a banker notices something odd and gently interrupts the scam",
    ],
}
DECK_ORDER = ["FORMAT", "COLD OPEN", "VOICE", "RHYTHM", "TRANSITIONS", "PAYOFF", "CTA", "WORLD"]

ANGLE_SHIFTS = [
    "PRIMARY: the main telling of this idea, balanced story and fixes",
    "VICTIM POV: retell everything from inside the victim's day, minute by minute",
    "PLAYBOOK: focus on the scammer's step-by-step playbook and why each step works",
    "FAMILY POV: tell it through the adult child who noticed the signs late",
    "FIX FIRST: open with the fix that saves money, then prove it through the story",
    "ONE YEAR LATER: revisit the case, what happened after, and what changed",
    "MYTH MODE: center the episode on what people wrongly believe about this scam",
    "NEAR MISS: tell it as someone who ALMOST fell for it and caught it in time",
    "RIPPLE: show how one scam hurt the whole family, not just the victim",
    "CHECKLIST: frame the whole episode as building a 5-point defense checklist",
]

# ============================================================
#  PROMPT DASAR — ambil dari file milik user agar selalu sinkron
# ============================================================
DEFAULT_BASE_PROMPT = """You are the head writer of "Spot The Scam" — a faceless YouTube channel
with stickman explainer videos, made for a US audience aged 55+.

=== MY INPUT ===
EPISODE IDEA:
[" Cari di reddit/berita yang sedang marak di us saat ini"]

FACTS & SOURCES — USE ONLY THESE. Do not invent, round up, or change any
number or case:
[TEMPEL FAKTA DARI RISET ANDA ]

=== TASK ===
Write the complete narration script for this episode.

=== HARD RULES ===
1. Simple American English, second person ("you"). Sentences under 15 words.
   Warm but urgent. A 70-year-old must understand every word.
2. Length: 1,550-1,700 words (about 11-12 minutes at 145 wpm).
3. Use ONLY the facts above. Every number and case must come from my sources.
   If you do not have a number, write the sentence without one. NEVER invent.
4. ZERO quotation marks anywhere. Report speech indirectly.
5. Plain narration text only: no markdown, no headings, no emojis, no stage
   directions, no scene labels.
6. Format: ONE paragraph = ONE scene. 25-32 paragraphs, 45-60 words each.
   Separate scenes with a line containing only ---
7. NO channel intro, no greeting. Start cold with the biggest number.

=== STRUCTURE ===
1. COLD OPEN (paragraph 1): the most shocking number from my sources + the
   unexpected place or moment + a promise of what this episode reveals.
2. BODY — MANY scams -> COUNTDOWN; ONE story -> STORY then 5 RED FLAGS.
3. EVERY scam item / red flag contains: scene sentence, step-by-step trick,
   real case or number with one human detail, THE FIX one concrete action.
4. MIDDLE CTA around halfway point.
5. PAYOFF near the end: the ONE thing all cases have in common.
6. ENDING CTA: ask viewers to comment which item they have seen."""


def load_base_prompt():
    p = os.path.join(BASE, 'Aprompt narasi.txt')
    try:
        if os.path.exists(p):
            t = open(p, encoding='utf-8').read().strip()
            if len(t) > 200:
                return t
    except Exception:
        pass
    return DEFAULT_BASE_PROMPT

# ============================================================
#  LOG — ingatan antar episode (anti-echo kombinasi & opening)
# ============================================================
def load_log():
    try:
        return json.load(open(LOG_FILE, encoding='utf-8'))
    except Exception:
        return {"last_ep": 0, "episodes": {}, "used_combos": [], "openings": []}


def save_log(log):
    log['used_combos'] = log['used_combos'][-5000:]
    json.dump(log, open(LOG_FILE, 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)

# ============================================================
#  PARSER file ide  (format:  ✅### NN. Judul / Angle / Pegangan fakta)
# ============================================================
def parse_ideas(text):
    lines = text.replace('\r', '').split('\n')
    starts = [i for i, l in enumerate(lines)
              if re.match(r'^\s*(?:[✅✓✔*\-+]\s*)?###\s', l)]
    ideas = []
    for k, i in enumerate(starts):
        end = starts[k + 1] if k + 1 < len(starts) else len(lines)
        block = '\n'.join(lines[i:end])
        m = re.match(r'^\s*(?:[✅✓✔*\-+]\s*)?###\s*(.+)$', lines[i])
        title = re.sub(r'^\d+\s*[.)\-:]\s*', '', (m.group(1) or '').strip())
        am = re.search(r'\*\*Angle\s*:?\*\*\s*:?\s*(.*?)(?=\n\s*\*\*|\Z)', block, re.S | re.I)
        fm = re.search(r'\*\*Pegangan\s+fakta\s*:?\*\*\s*:?\s*(.*?)(?=\n\s*\*\*(?![Pp]egangan)|\Z)',
                       block, re.S | re.I)
        angle = re.sub(r'\s+', ' ', (am.group(1) or '').strip()) if am else ''
        facts = (fm.group(1) or '').strip() if fm else ''
        if title or facts:
            ideas.append({'title': title or 'Tanpa judul', 'angle': angle, 'facts': facts})
    if not ideas and text.strip():
        first = next((l.strip() for l in lines if l.strip()), 'Ide tanpa judul')
        ideas.append({'title': first[:90], 'angle': '', 'facts': text.strip()})
    return ideas

# ============================================================
#  MESIN VARIASI — kombinasi unik, tanpa pengulangan beruntun
# ============================================================
def assign_batch(seed, n, prev_combo, used):
    out, prev = [], prev_combo
    for i in range(n):
        rng = random.Random('%s:%d' % (seed, i))
        combo = None
        for _ in range(400):
            cand = {}
            for cat, opts in DECK.items():
                pool = [o for o in opts if not prev or o != prev.get(cat)]
                cand[cat] = rng.choice(pool or opts)
            key = tuple(cand[c] for c in DECK_ORDER)
            if key not in used:
                combo = cand
                break
        if combo is None:
            combo = {cat: rng.choice(opts) for cat, opts in DECK.items()}
        used.add(tuple(combo[c] for c in DECK_ORDER))
        out.append(combo)
        prev = combo
    return out

# ============================================================
#  PERAKIT PROMPT
# ============================================================
def build_prompt(base, ep_no, idea, combo, shift, openings, with_tags):
    txt = base.replace('\r', '')

    idea_block = 'EPISODE %03d — "%s"' % (ep_no, idea['title'])
    if idea.get('angle'):
        idea_block += '\nAngle to emphasize: ' + idea['angle']
    txt = re.sub(r'(EPISODE IDEA:\s*\n)\s*\[[^\]]*\]',
                 lambda m: m.group(1) + idea_block, txt, count=1)

    facts = idea.get('facts', '').strip() or '(belum ada — riset dulu sebelum generate naskah)'
    facts += ('\nIf newer FBI / FTC / state Attorney General / US news facts about this '
              'scam are given to you later, you may use them — still obey the source rules above.')
    txt = re.sub(r'\[TEMPEL FAKTA[^\]]*\]', facts, txt, count=1)

    v = ['=== EPISODE %03d VARIABLES (chosen at random for THIS episode — follow ALL strictly) ===' % ep_no]
    for cat in DECK_ORDER:
        v.append('%s: %s' % (cat, combo[cat]))
    if shift and not shift.startswith('PRIMARY'):
        v.append('ANGLE SHIFT for this variant: %s' % shift)

    v += ['',
          '=== ADDITIONAL HARD RULES (these WIN over any conflicting default above) ===',
          '8. The EPISODE VARIABLES above override the default STRUCTURE wherever they conflict.',
          '9. RETENTION: first sentence under 12 words. Paragraph 1 ends with a promise of what '
          'the viewer gets by staying. Plant one mini-cliffhanger sentence at paragraphs 4, 8, 12, 16, 20. '
          'Every THE FIX is one short do-it-today sentence.',
          '10. Do NOT start like any of these previous episode openings — be different from all of them:']
    last5 = openings[-5:] if openings else []
    if last5:
        v += ['    - %s' % o for o in last5]
    else:
        v.append('    (this is the first episode)')
    if with_tags:
        v.append('11. After the script, add: (a) a UNIQUE 3-4 sentence video description built only from '
                 'this episode facts, and (b) 5 specific tags. Never reuse description patterns from other episodes.')

    return txt + '\n\n' + '\n'.join(v) + '\n'

# ============================================================
#  FLASK — gabungkan dengan app studio lama (tanpa mengubahnya)
# ============================================================
STUDIO_OK = True
try:
    import a2studio
    app = a2studio.app
except Exception as e:
    STUDIO_OK = False
    try:
        from flask import Flask
        app = Flask(__name__)
    except ImportError:
        print('Flask belum terpasang:  pip install flask')
        sys.exit(1)
    print('  !! a2studio tidak bisa dimuat (%s) — mode HANYA halaman narasi.' % e)

from flask import request, jsonify, Response, send_file
import visual_deck as vd
import concept_deck as cd

MARK_A = '# >>> TEMPLATE AKTIF dari halaman /visual (otomatis) >>>'
MARK_B = '# <<< TEMPLATE AKTIF <<<'


@app.get('/narasi')
def narasi_page():
    return Response(NARASI_HTML.replace('__STUDIO_OK__',
                                        '1' if STUDIO_OK else '0'),
                    mimetype='text/html',
                    headers={'Cache-Control': 'no-store'})


@app.get('/api/narasi/state')
def narasi_state():
    ideas_text = ''
    try:
        if os.path.exists(IDEAS_FILE):
            ideas_text = open(IDEAS_FILE, encoding='utf-8').read()
    except Exception:
        pass
    log = load_log()
    return jsonify({'ideas': ideas_text,
                    'last_ep': log.get('last_ep', 0),
                    'openings': log.get('openings', []),
                    'studio_ok': STUDIO_OK})


@app.post('/api/narasi/ideas')
def narasi_save_ideas():
    d = request.get_json(force=True)
    text = (d.get('text') or '').strip()
    try:
        open(IDEAS_FILE, 'w', encoding='utf-8').write(text)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    ideas = parse_ideas(text)
    return jsonify({'saved': True, 'parsed': len(ideas),
                    'titles': [i['title'][:70] for i in ideas[:12]]})


@app.post('/api/narasi/openings')
def narasi_openings():
    d = request.get_json(force=True)
    lines = [l.strip(' -\t') for l in (d.get('text') or '').splitlines() if l.strip()]
    log = load_log()
    ada = set(log.get('openings', []))
    for l in lines:
        if l not in ada:
            log['openings'].append(l[:200])
            ada.add(l)
    log['openings'] = log['openings'][-20:]
    save_log(log)
    return jsonify({'openings': log['openings']})


@app.post('/api/narasi/generate')
def narasi_generate():
    d = request.get_json(force=True)
    ideas = parse_ideas(d.get('ideas', ''))
    if not ideas:
        return jsonify({'error': 'Tidak ada ide yang bisa dibaca. Tempel minimal 1 ide.'}), 400
    per   = max(1, min(10, int(d.get('per_idea', 1))))
    log   = load_log()
    start = max(1, int(d.get('start_ep') or (log.get('last_ep', 0) + 1)))
    seed  = d.get('seed') or int(time.time() * 1000) % 1000000
    with_tags = d.get('with_tags', True)
    with_visual = d.get('with_visual', False)
    v_last = log.get('visual_last', 0)

    slots  = [(idea, vi) for idea in ideas for vi in range(per)]
    used   = set(tuple(c) for c in log.get('used_combos', []))
    prev   = None
    last_n = str(log.get('last_ep', 0))
    if log.get('episodes', {}).get(last_n, {}).get('combo'):
        prev = {c: v for c, v in zip(DECK_ORDER, log['episodes'][last_n]['combo'])}
    combos = assign_batch(seed, len(slots), prev, used)

    episodes, rows = [], []
    openings = log.get('openings', [])
    base = load_base_prompt()
    for n, ((idea, vi), combo) in enumerate(zip(slots, combos)):
        ep_no = start + n
        shift = ANGLE_SHIFTS[vi % len(ANGLE_SHIFTS)] if per > 1 else ANGLE_SHIFTS[0]
        prompt = build_prompt(base, ep_no, idea, combo, shift, openings, with_tags)
        vt = 0
        if with_visual:
            vt = ((v_last + n) % vd.N_TEMPLATES) + 1
            prompt += '\n' + vd.visual_block(vt) + '\n'
            prompt += '\n' + cd.concept_block(vt) + '\n'
        episodes.append({'no': ep_no, 'title': idea['title'],
                         'variant': vi + 1 if per > 1 else 0,
                         'vt': vt, 'vars': combo, 'prompt': prompt})
        rows.append([ep_no, idea['title']] + [combo[c] for c in DECK_ORDER])
        log.setdefault('episodes', {})[str(ep_no)] = {
            'title': idea['title'],
            'combo': [combo[c] for c in DECK_ORDER]}

    log['last_ep'] = max(log.get('last_ep', 0), start + len(episodes) - 1)
    if with_visual:
        log['visual_last'] = (v_last + len(episodes)) % vd.N_TEMPLATES
    log['used_combos'] = (log.get('used_combos', []) +
                          [[c[c2] for c2 in DECK_ORDER] for c in combos])
    save_log(log)
    return jsonify({'episodes': episodes, 'rows': rows,
                    'seed': seed, 'start': start,
                    'n_ideas': len(ideas), 'per_idea': per})

# ============================================================
#  VISUAL — route untuk /visual
# ============================================================
@app.get('/visual')
def visual_page():
    return Response(VISUAL_HTML.replace('__STUDIO_OK__',
                                        '1' if STUDIO_OK else '0'),
                    mimetype='text/html',
                    headers={'Cache-Control': 'no-store'})


@app.get('/api/visual/template/<int:tn>')
def visual_template(tn):
    t = vd.get_template(tn)
    t['visual_block'] = vd.visual_block(tn)
    return jsonify(t)


@app.get('/visual/preview/<int:tn>.png')
def visual_preview(tn):
    tn = ((tn - 1) % vd.N_TEMPLATES) + 1
    # utamakan latar pra-render (file nyata), cepat & stabil
    pre = os.path.join(BASE, 'assets', 'vpackbg', 'vk%03d.png' % tn)
    if os.path.exists(pre):
        return send_file(pre, mimetype='image/png')
    cache = os.path.join(DRIVE, 'visual_cache')
    os.makedirs(cache, exist_ok=True)
    out = os.path.join(cache, 'vt%03d.png' % tn)
    if not os.path.exists(out):
        try:
            vd.build_preview(tn, out)
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    return send_file(out, mimetype='image/png')


@app.post('/api/visual/apply')
def visual_apply():
    d = request.get_json(force=True)
    t = vd.get_template(int(d.get('n', 1)))
    p = os.path.join(BASE, 'motifs.dat')
    try:
        txt = open(p, encoding='utf-8').read()
    except Exception:
        txt = ''
    # buang blok template aktif lama
    while MARK_A in txt and MARK_B in txt:
        a, rest = txt.split(MARK_A, 1)
        _, rest = rest.split(MARK_B, 1)
        txt = a + rest.lstrip('\n')
    block = MARK_A + '\n' + t['motif_line'] + '\n' + MARK_B + '\n'
    if '# ---- contoh custom' in txt:
        head, tail = txt.split('# ---- contoh custom', 1)
        nl = tail.find('\n')
        txt = (head + '# ---- contoh custom' + tail[:nl + 1] + block + tail[nl + 1:])
    else:
        txt = block + txt
    open(p, 'w', encoding='utf-8').write(txt)
    return jsonify({'applied': t['name'], 'motif_line': t['motif_line']})


@app.get('/visual/templates.csv')
def visual_csv():
    import io
    out = io.StringIO()
    out.write('template,tema,kata_kunci,aktor,properti,latar,baris_motif\n')
    for tn in range(1, vd.N_TEMPLATES + 1):
        t = vd.get_template(tn)
        row = [tn, t['title'], '; '.join(t['keywords']), t['actors'],
               t['props'], t['latar'], t['motif_line']]
        out.write(','.join('"%s"' % str(x).replace('"', '""') for x in row) + '\n')
    return Response(out.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition':
                             'attachment; filename=visual_templates_500.csv'})


# ============================================================
#  HALAMAN  /narasi
# ============================================================
NARASI_HTML = r"""<!DOCTYPE html><html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Spot The Scam — Prompt Narasi</title>
<style>
:root{--navy:#12275A;--navy2:#0D1B3E;--amber:#FFC53D;--red:#E02020;--bg:#F4F6FB;--ok:#1E7E34}
*{box-sizing:border-box}
body{margin:0;font-family:'Segoe UI',system-ui,Arial,sans-serif;background:var(--bg);color:#1B2437}
header{background:linear-gradient(135deg,var(--navy),var(--navy2));color:#fff;
  padding:16px 22px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}
header .dot{width:38px;height:38px;border-radius:10px;background:var(--amber);
  display:flex;align-items:center;justify-content:center;font-size:20px}
header h1{font-size:19px;margin:0;letter-spacing:.3px}
header small{opacity:.75;display:block;font-weight:400}
header .sp{flex:1}
a.btn-link{color:var(--navy);background:#fff;text-decoration:none;font-weight:700;
  padding:9px 14px;border-radius:9px;font-size:13px}
.wrap{max-width:1280px;margin:18px auto;padding:0 16px;display:grid;
  grid-template-columns:430px 1fr;gap:16px}
@media(max-width:980px){.wrap{grid-template-columns:1fr}}
.card{background:#fff;border-radius:14px;box-shadow:0 2px 10px rgba(18,39,90,.08);
  padding:18px;margin-bottom:16px}
.card h2{margin:0 0 10px;font-size:15px;color:var(--navy);display:flex;align-items:center;gap:8px}
.card h2 .n{background:var(--navy);color:#fff;border-radius:50%;width:22px;height:22px;
  display:inline-flex;align-items:center;justify-content:center;font-size:12px}
textarea{width:100%;border:1.5px solid #D6DEEF;border-radius:10px;padding:10px;
  font-family:Consolas,monospace;font-size:12.5px;resize:vertical;background:#FBFCFF}
textarea:focus{outline:none;border-color:var(--navy)}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:10px 0}
label.f{font-size:12.5px;font-weight:600;color:#445}
input[type=number],input[type=text]{border:1.5px solid #D6DEEF;border-radius:8px;
  padding:7px 9px;font-size:13px;width:88px;background:#FBFCFF}
button{border:0;border-radius:10px;padding:11px 16px;font-size:14px;font-weight:800;
  cursor:pointer;transition:.15s}
button.primary{background:var(--navy);color:#fff}
button.primary:hover{background:#1B3A80}
button.amber{background:var(--amber);color:var(--navy)}
button.ghost{background:#EDF1FA;color:var(--navy)}
button:disabled{opacity:.5;cursor:wait}
.chip{display:inline-block;background:#EDF1FA;color:var(--navy);border-radius:20px;
  padding:3px 10px;font-size:11px;font-weight:700;margin:2px 3px 2px 0}
.chip b{color:#7A86A5;font-weight:600;margin-right:4px}
details.ep{border:1.5px solid #E2E8F5;border-radius:12px;margin-bottom:10px;background:#fff;overflow:hidden}
details.ep summary{cursor:pointer;padding:12px 14px;font-weight:700;font-size:13.5px;
  display:flex;gap:10px;align-items:center;list-style:none;background:#FBFCFF}
details.ep summary::-webkit-details-marker{display:none}
details.ep .no{background:var(--amber);color:var(--navy);border-radius:8px;padding:2px 9px;
  font-size:12px;font-weight:800;white-space:nowrap}
details.ep .vt{color:#8A93AB;font-size:11px;font-weight:600}
details.ep .body{padding:12px 14px}
.stats{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.stat{background:var(--navy);color:#fff;border-radius:12px;padding:10px 16px;min-width:110px}
.stat b{display:block;font-size:21px;color:var(--amber)}
.stat span{font-size:11px;opacity:.85}
.msg{font-size:13px;padding:9px 12px;border-radius:9px;margin:8px 0}
.msg.ok{background:#E7F5EA;color:var(--ok)}
.msg.err{background:#FDECEC;color:var(--red)}
.msg.info{background:#EEF2FB;color:var(--navy)}
.copymini{font-size:11px;padding:5px 10px;border-radius:7px;background:#EDF1FA;color:var(--navy);font-weight:700}
.hint{font-size:12px;color:#7A86A5;line-height:1.5}
#spin{display:none;width:15px;height:15px;border:3px solid #fff;border-top-color:transparent;
  border-radius:50%;animation:r 1s linear infinite;vertical-align:-2px;margin-right:6px}
@keyframes r{to{transform:rotate(360deg)}}
</style></head><body>
<header>
  <div class="dot">🎬</div>
  <h1>PROMPT NARASI<small>generator episode unik — Spot The Scam · sub-halaman baru, UI lama tidak diubah</small></h1>
  <div class="sp"></div>
  <a class="btn-link" href="/" id="studioLink">← Buka Studio Utama</a>
</header>

<div class="wrap">
 <div>
  <div class="card">
    <h2><span class="n">1</span> Tempel ide episode</h2>
    <textarea id="ideas" rows="16" placeholder="Tempel isi file ide di sini...
Format yang dikenali:

✅### 01. Judul Episode
**Angle:** sudut cerita...
**Pegangan fakta:** fakta + sumber/link..."></textarea>
    <div class="row">
      <button class="ghost" onclick="saveIdeas()">💾 Simpan ke drive/ide_episoda.txt</button>
      <span id="savemsg" class="hint"></span>
    </div>
  </div>

  <div class="card">
    <h2><span class="n">2</span> Atur generate</h2>
    <div class="row">
      <label class="f">Prompt per ide
        <input type="number" id="per" value="1" min="1" max="10"></label>
      <label class="f">Episode mulai no.
        <input type="number" id="start" min="1" placeholder="auto"></label>
      <label class="f">Seed (opsional)
        <input type="text" id="seed" placeholder="acak"></label>
    </div>
    <div class="row">
      <label class="f"><input type="checkbox" id="tags" checked> sertakan aturan DESCRIPTION &amp; TAGS unik</label>
    </div>
    <div class="row">
      <label class="f"><input type="checkbox" id="visual" checked> lampirkan VISUAL TEMPLATE otomatis
        (1 template unik / episode — lihat di <a href="/visual" target="_blank">/visual</a>)</label>
    </div>
    <div class="row">
      <button class="primary" id="gen" onclick="generate()"><span id="spin"></span>⚡ Generate Prompt Unik</button>
      <button class="ghost" onclick="copyAll()">📋 Salin semua</button>
      <button class="ghost" onclick="downloadTxt()">⬇ .txt</button>
      <button class="ghost" onclick="downloadCsv()">⬇ ringkasan .csv</button>
    </div>
    <div id="msgbox"></div>
    <p class="hint">Setiap prompt dibekali kombinasi acak <b>FORMAT · COLD OPEN · VOICE · RHYTHM ·
    TRANSITIONS · PAYOFF · CTA</b> (192.000 kombinasi) + aturan retensi detik pertama +
    memori opening episode sebelumnya. Kombinasi tersimpan di
    <b>drive/narasi_log.json</b> supaya tidak pernah terulang.</p>
  </div>

  <div class="card">
    <h2><span class="n">3</span> Memori opening (anti-echo)</h2>
    <p class="hint">Setelah naskah jadi, tempel <b>kalimat pertama</b> tiap episode di sini
    (satu per baris). Lima kalimat terbaru otomatis dimasukkan ke semua prompt berikutnya
    dengan perintah “jangan mulai seperti ini”.</p>
    <textarea id="opens" rows="4" placeholder="Kalimat pertama episode yang sudah jadi..."></textarea>
    <div class="row">
      <button class="ghost" onclick="saveOpenings()">💾 Tambahkan ke memori</button>
      <span id="openmsg" class="hint"></span>
    </div>
  </div>
 </div>

 <div>
  <div class="card">
    <h2><span class="n">4</span> Hasil generate</h2>
    <div id="stats" class="stats" style="display:none"></div>
    <div id="results"><p class="hint">Belum ada hasil — tempel ide lalu klik
      <b>⚡ Generate Prompt Unik</b>.</p></div>
  </div>
 </div>
</div>

<script>
let LAST=null;
const $=id=>document.getElementById(id);
if('__STUDIO_OK__'==='0'){$('studioLink').style.display='none';}

function msg(t,cls){$('msgbox').innerHTML='<div class="msg '+cls+'">'+t+'</div>';}

async function load(){
  const j=await (await fetch('/api/narasi/state')).json();
  if(j.ideas)$('ideas').value=j.ideas;
  if(j.last_ep)$('start').placeholder='auto ('+(j.last_ep+1)+')';
  if(j.openings&&j.openings.length)
    $('openmsg').textContent=j.openings.length+' opening tersimpan di memori';
}

async function saveIdeas(){
  const j=await (await fetch('/api/narasi/ideas',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text:$('ideas').value})})).json();
  $('savemsg').textContent=j.error?('GAGAL: '+j.error)
    :('✔ tersimpan — '+j.parsed+' ide terbaca');
}

async function saveOpenings(){
  const j=await (await fetch('/api/narasi/openings',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text:$('opens').value})})).json();
  $('opens').value='';
  $('openmsg').textContent='✔ '+(j.openings||[]).length+' opening di memori';
}

async function generate(){
  $('gen').disabled=true;$('spin').style.display='inline-block';
  try{
    const r=await fetch('/api/narasi/generate',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ideas:$('ideas').value,
        per_idea:+$('per').value||1,start_ep:$('start').value||0,
        seed:$('seed').value||'',with_tags:$('tags').checked,
        with_visual:$('visual').checked})});
    const j=await r.json();
    if(j.error){msg('⚠ '+j.error,'err');return}
    LAST=j;render(j);
    msg('✔ '+(j.episodes.length)+' prompt unik dibuat (seed '+j.seed+')','ok');
  }catch(e){msg('ERROR: '+e,'err');}
  finally{$('gen').disabled=false;$('spin').style.display='none';}
}

function chips(v){const L=['FORMAT','COLD OPEN','VOICE','RHYTHM','TRANSITIONS','PAYOFF','CTA'];
  return L.map(k=>'<span class="chip"><b>'+k+'</b>'+v[k].split(':')[0]+'</span>').join('');}

function render(j){
  $('stats').style.display='flex';
  $('stats').innerHTML=
    '<div class="stat"><b>'+j.n_ideas+'</b><span>ide</span></div>'+
    '<div class="stat"><b>'+j.per_idea+'</b><span>varian / ide</span></div>'+
    '<div class="stat"><b>'+j.episodes.length+'</b><span>prompt unik</span></div>'+
    '<div class="stat"><b>Ep '+j.episodes[0].no+'–'+j.episodes[j.episodes.length-1].no+'</b><span>nomor episode</span></div>';
  $('results').innerHTML=j.episodes.map((e,i)=>
    '<details class="ep"><summary><span class="no">EP '+String(e.no).padStart(3,'0')+'</span>'+
    '<span>'+e.title+'</span>'+
    (e.variant?'<span class="vt">varian '+e.variant+'</span>':'')+
    (e.vt?'<span class="vt" style="color:#B8860B">VT-'+String(e.vt).padStart(3,'0')+'</span>':'')+
    '<span style="flex:1"></span><button class="copymini" onclick="event.preventDefault();copyOne('+i+')">📋 salin</button></summary>'+
    '<div class="body">'+chips(e.vars)+
    (e.vt?'<span class="chip" style="background:#FFC53D"><b>VISUAL</b><a href="/visual?t='+e.vt+'" target="_blank" style="color:var(--navy);text-decoration:none">VT-'+String(e.vt).padStart(3,'0')+'</a></span>':'')+
    '<textarea rows="14" id="p'+i+'" readonly>'+esc(e.prompt)+'</textarea></div></details>').join('');
}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function copyText(t,btn){const done=()=>{if(btn){btn.textContent='✔';setTimeout(()=>btn.textContent='📋 salin',900)}};
  if(navigator.clipboard){navigator.clipboard.writeText(t).then(done).catch(()=>fallback(t,done));}
  else fallback(t,done);}
function fallback(t,done){const ta=document.createElement('textarea');ta.value=t;
  document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();done();}
function copyOne(i){copyText(LAST.episodes[i].prompt);}
function copyAll(){copyText(allTxt(),null);msg('✔ semua prompt disalin ke clipboard','ok');}
function allTxt(){return LAST.episodes.map(e=>
  '══════════════ EPISODE '+String(e.no).padStart(3,'0')+' — '+e.title+
  (e.variant?' (varian '+e.variant+')':'')+' ══════════════\n\n'+e.prompt).join('\n\n');}
function downloadTxt(){if(!LAST){msg('Generate dulu','err');return}
  dl('prompt_narasi_ep'+LAST.episodes[0].no+'-'+LAST.episodes[LAST.episodes.length-1].no+'.txt',allTxt());}
function downloadCsv(){if(!LAST){msg('Generate dulu','err');return}
  const head=['episode','judul'].concat(['FORMAT','COLD OPEN','VOICE','RHYTHM','TRANSITIONS','PAYOFF','CTA']);
  const csv=[head].concat(LAST.rows).map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');
  dl('ringkasan_variasi_ep'+LAST.episodes[0].no+'.csv',csv);}
function dl(name,content){const b=new Blob([content],{type:'text/plain;charset=utf-8'});
  const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),3000);}
load();
</script>
</body></html>"""

# ============================================================
#  HALAMAN  /visual
# ============================================================
VISUAL_HTML = r"""<!DOCTYPE html><html lang="id"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Spot The Scam — 500 Template Visual</title>
<style>
:root{--navy:#12275A;--navy2:#0D1B3E;--amber:#FFC53D;--red:#E02020;--bg:#F4F6FB;--ok:#1E7E34}
*{box-sizing:border-box}
body{margin:0;font-family:'Segoe UI',system-ui,Arial,sans-serif;background:var(--bg);color:#1B2437}
header{background:linear-gradient(135deg,var(--navy),var(--navy2));color:#fff;
  padding:16px 22px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}
header .dot{width:38px;height:38px;border-radius:10px;background:var(--amber);
  display:flex;align-items:center;justify-content:center;font-size:20px}
header h1{font-size:19px;margin:0}
header small{opacity:.75;display:block;font-weight:400}
header .sp{flex:1}
a.btn-link{color:var(--navy);background:#fff;text-decoration:none;font-weight:700;
  padding:9px 14px;border-radius:9px;font-size:13px}
.wrap{max-width:1200px;margin:18px auto;padding:0 16px;display:grid;
  grid-template-columns:360px 1fr;gap:16px}
@media(max-width:980px){.wrap{grid-template-columns:1fr}}
.card{background:#fff;border-radius:14px;box-shadow:0 2px 10px rgba(18,39,90,.08);
  padding:18px;margin-bottom:16px}
.card h2{margin:0 0 10px;font-size:15px;color:var(--navy)}
input[type=number]{border:1.5px solid #D6DEEF;border-radius:8px;padding:8px 10px;
  font-size:15px;width:100px;background:#FBFCFF;font-weight:700}
button{border:0;border-radius:10px;padding:10px 14px;font-size:13.5px;font-weight:800;cursor:pointer}
button.primary{background:var(--navy);color:#fff}
button.amber{background:var(--amber);color:var(--navy)}
button.ghost{background:#EDF1FA;color:var(--navy)}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:10px 0}
img.prev{width:100%;border-radius:12px;border:1.5px solid #E2E8F5;display:block}
table.det{width:100%;border-collapse:collapse;font-size:13px}
table.det td{padding:7px 8px;border-bottom:1px solid #EEF1F8;vertical-align:top}
table.det td:first-child{font-weight:800;color:var(--navy);width:120px;white-space:nowrap}
textarea{width:100%;border:1.5px solid #D6DEEF;border-radius:10px;padding:10px;
  font-family:Consolas,monospace;font-size:12px;background:#FBFCFF;resize:vertical}
code.motif{display:block;background:#0D1B3E;color:#9FE8B0;border-radius:10px;
  padding:10px 12px;font-size:11.5px;word-break:break-all}
.msg{font-size:13px;padding:9px 12px;border-radius:9px;margin:8px 0}
.msg.ok{background:#E7F5EA;color:var(--ok)}
.msg.err{background:#FDECEC;color:var(--red)}
.hint{font-size:12px;color:#7A86A5;line-height:1.55}
.kw{display:inline-block;background:#FFF6DC;color:#8a6d00;border:1px solid #F0DFA8;
  border-radius:20px;padding:3px 10px;font-size:12px;font-weight:700;margin:2px 3px 2px 0}
</style></head><body>
<header>
  <div class="dot">🎨</div>
  <h1>500 TEMPLATE VISUAL<small>anti-visual-template: karakter · objek · latar · furnitur berbeda tiap episode</small></h1>
  <div class="sp"></div>
  <a class="btn-link" href="/narasi">📄 Prompt Narasi</a>
  <a class="btn-link" href="/">🎬 Studio Utama</a>
</header>

<div class="wrap">
 <div>
  <div class="card">
    <h2>Pilih template (1–500)</h2>
    <div class="row">
      <input type="number" id="tn" min="1" max="500" value="1">
      <button class="ghost" onclick="go(cur-1)">⬅</button>
      <button class="ghost" onclick="go(cur+1)">➡</button>
      <button class="ghost" onclick="go(1+Math.floor(Math.random()*500))">🎲 acak</button>
    </div>
    <div class="row">
      <button class="amber" onclick="apply()">💾 Terapkan ke Studio (tulis motifs.dat)</button>
    </div>
    <div class="row">
      <button class="ghost" onclick="copyTxt('motif')">📋 baris motif</button>
      <button class="ghost" onclick="copyTxt('vblock')">📋 blok VISUAL DIRECTION</button>
      <a class="btn-link" style="padding:9px 12px;font-size:12px" href="/visual/templates.csv">⬇ CSV 500 template</a>
    </div>
    <div id="msgbox"></div>
    <p class="hint">Alur per episode: (1) pilih template sesuai nomornya di kartu hasil
    generate narasi, (2) klik <b>Terapkan ke Studio</b> → baris motif ditulis ke
    <b>motifs.dat</b> (baris lama dari halaman ini otomatis diganti), (3) render episode
    itu di studio. Mesin scene akan memakai komposisi template saat narasi menyebut
    kata kuncinya.</p>
  </div>
 </div>

 <div>
  <div class="card">
    <h2 id="judul">Template</h2>
    <img class="prev" id="prev" alt="preview">
    <table class="det" style="margin-top:12px">
      <tr><td>KONSEP</td><td id="concept"></td></tr>
      <tr><td>KATA KUNCI</td><td id="kws"></td></tr>
      <tr><td>KARAKTER</td><td id="actors"></td></tr>
      <tr><td>PROPERTI</td><td id="props"></td></tr>
      <tr><td>LATAR</td><td id="latar"></td></tr>
      <tr><td>FURNITUR</td><td id="furni"></td></tr>
      <tr><td>BARIS MOTIF</td><td><code class="motif" id="motif"></code></td></tr>
    </table>
  </div>
  <div class="card">
    <h2>Blok VISUAL DIRECTION (otomatis ikut saat generate narasi)</h2>
    <textarea id="vblock" rows="8" readonly></textarea>
  </div>
 </div>
</div>

<script>
let cur=1;
const $=id=>document.getElementById(id);
function msg(t,c){$('msgbox').innerHTML='<div class="msg '+c+'">'+t+'</div>';}
async function go(n){
  cur=Math.min(500,Math.max(1,n));$('tn').value=cur;
  const t=await (await fetch('/api/visual/template/'+cur)).json();
  $('judul').textContent='VT-'+String(cur).padStart(3,'0')+' — '+t.title;
  $('prev').src='/visual/preview/'+cur+'.png?_='+Date.now();
  $('concept').innerHTML='<span class="kw">ALUR '+t.concept.alur+'</span>'+
    '<span class="kw">GERAK '+t.concept.gerak+'</span>'+
    '<span class="kw">CAMERA '+t.concept.camera+'</span>'+
    '<span class="kw">STAGING '+t.concept.staging+'</span>'+
    '<span class="kw">PROP '+t.concept.propm+'</span>';
  $('kws').innerHTML=t.keywords.map(k=>'<span class="kw">'+k+'</span>').join('');
  $('actors').textContent=t.actors.replace(/;/g,'  (kiri) vs  ');
  $('props').textContent=t.props;
  $('latar').textContent=t.latar+'  ·  bg: '+t.bg_file+' ('+t.palette+')';
  $('furni').textContent=t.furni.join('  ·  ');
  $('motif').textContent=t.motif_line;
  $('vblock').value=t.visual_block;
}
async function apply(){
  const j=await (await fetch('/api/visual/apply',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({n:cur})})).json();
  msg(j.applied?('✔ aktif di motifs.dat: <b>'+j.applied+'</b> — lanjut render episode ini di studio.')
      :'gagal','ok');
}
function copyTxt(w){const t=$(w).textContent||$(w).value;
  (navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(
    ()=>msg('✔ disalin','ok')).catch(()=>{const ta=$(w);ta.select();document.execCommand('copy');msg('✔ disalin','ok');});}
$('tn').addEventListener('change',e=>go(+e.target.value||1));
const q=new URLSearchParams(location.search).get('t');
go(q?+q:1);
</script>
</body></html>"""

# ============================================================
#  MAIN — pola port/popup sama seperti studio asli
# ============================================================
def _port_bebas(port):
    t = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    t.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        t.bind(('0.0.0.0', port)); t.close(); return True
    except OSError:
        return False


def _bunuh_lama():
    saya = os.getpid()
    n = 0
    try:
        for d in os.listdir('/proc'):
            if not d.isdigit():
                continue
            pid = int(d)
            if pid == saya:
                continue
            argv = [x for x in open('/proc/%d/cmdline' % pid, 'rb')
                    .read().decode('utf-8', 'replace').split('\0') if x]
            if len(argv) >= 2 and argv[1].split('/')[-1] in ('a2studio.py', 'promptnarasi.py'):
                os.kill(pid, 15)
                n += 1
    except Exception:
        pass
    return n


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8808)
    ap.add_argument('--host', default='0.0.0.0')
    a = ap.parse_args()

    if not _port_bebas(a.port):
        _bunuh_lama()
        time.sleep(1.5)
        if not _port_bebas(a.port):
            for p in range(a.port + 1, a.port + 11):
                if _port_bebas(p):
                    print('  !! Port %d sibuk -> pindah ke %d' % (a.port, p))
                    a.port = p
                    break
            else:
                sys.exit('  !! Semua port sibuk.')

    def popup():
        if os.environ.get('A2_NO_BROWSER'):
            return
        if not os.environ.get('DISPLAY') and sys.platform != 'darwin':
            print('  (tanpa layar — buka manual: http://localhost:%d/narasi)' % a.port)
            return
        url = 'http://localhost:%d/narasi' % a.port
        time.sleep(1.2)
        for name, extra in (('chromium', ['--app=' + url, '--start-maximized']),
                            ('chromium-browser', ['--app=' + url]),
                            ('google-chrome', ['--app=' + url]),
                            ('firefox', ['--new-window', url])):
            exe = shutil.which(name)
            if exe:
                try:
                    subprocess.Popen([exe] + extra, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
                    return
                except Exception:
                    continue
        try:
            subprocess.Popen(['xdg-open', url], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        except Exception:
            pass

    threading.Thread(target=popup, daemon=True).start()
    mode = 'Studio + Narasi' if STUDIO_OK else 'HANYA Narasi (a2studio gagal dimuat)'
    print('A2 Studio v5 [%s] -> http://localhost:%d' % (mode, a.port))
    print('Sub-halaman prompt narasi -> http://localhost:%d/narasi' % a.port)
    app.run(host=a.host, port=a.port, debug=False)
