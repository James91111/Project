#!/usr/bin/env python3
# ============================================================
#  KINETIC — teks sinematik di atas animasi stickman
#  Aturan: teks SELALU di pita atas layar (tidak menutupi karakter)
#  Gaya: big / box / quote / warn / num  (bergilir otomatis)
# ============================================================
import os
from PIL import Image, ImageDraw, ImageFont

CANDIDATES = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets', 'fonts'),   # layout ZIP
    os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'fonts'),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fonts'),
    '/home/user/assets/fonts',
]
if os.environ.get('A2_BASE'):
    CANDIDATES.insert(0, os.path.join(os.environ['A2_BASE'], 'assets', 'fonts'))
FONTS = {}
_FONT_WARN = False
def _font(weight, size):
    global _FONT_WARN
    key = (weight, size)
    if key not in FONTS:
        path = None
        for c in CANDIDATES:
            p = os.path.join(c, f'Montserrat-{weight}.ttf')
            if os.path.exists(p): path = p; break
        if path is None:
            # v4.3: font darurat TETAP UKURAN BESAR (dulu: kecil -> subtitle mungil)
            try:
                FONTS[key] = ImageFont.load_default(size)
            except TypeError:
                FONTS[key] = ImageFont.load_default()
            if not _FONT_WARN:
                _FONT_WARN = True
                print('KINETIC: Montserrat tidak ketemu — pakai font darurat ukuran penuh')
            return FONTS[key]
        FONTS[key] = ImageFont.truetype(path, size)
    return FONTS[key]

INK   = (30, 34, 58)
AMBER = (255, 184, 28)
RED   = (226, 54, 54)
GRAY  = (120, 128, 146)
BAND  = (255, 255, 255)

def wrap(d, text, font, maxw):
    words, lines, cur = text.split(), [], ''
    for w_ in words:
        t = (cur + ' ' + w_).strip()
        if d.textlength(t, font=font) <= maxw: cur = t
        else: lines.append(cur); cur = w_
    if cur: lines.append(cur)
    return lines

WARN_WORDS = ('scam', 'fake', 'never', 'warning', 'stop', 'danger', 'police', 'illegal')

def pick_style(chunk, cycle):
    low = chunk.lower()
    if any(w in low for w in WARN_WORDS): return 'warn'
    if low.startswith(('number ', 'step ')): return 'num'      # v4.5: countdown
    if any(ch.isdigit() or ch == '$' for ch in chunk): return 'num'
    return ('big', 'box')[cycle % 2]   # quote dihapus (bug tanda petik melayang)

def draw_chunk(img, text, style, prog):
    """v5 SENIOR (riset 55+): SATU gaya konsisten -- pita gelap semi-transparan
    di ZONA BAWAH (konvensi subtitle, tak menutup wajah/aksi), teks putih besar
    sans-serif (kontras >12:1), aksen amber untuk peringatan/angka (tanpa pita
    merah menyilaukan). Muncul & lenyap lembut (tanpa pop kaget)."""
    appear = min(1.0, prog * 4.0)
    fade   = min(1.0, (1.0 - prog) * 4.0)
    alpha  = int(255 * appear * fade)
    if alpha <= 3: return img
    cx = 960
    size = 104                                   # +-9.6% tinggi frame: besar utk 55+
    f = _font(800, size)
    lines = wrap(d0 := ImageDraw.Draw(img, 'RGBA'), text, f, 1660)
    lh = int(size * 1.28)                        # spasi 128%: nyaman mata tua
    total_h = len(lines) * lh
    tw = max(d0.textlength(t, font=f) for t in lines)
    pad_x, pad_y = 56, 30
    bw = tw + pad_x * 2
    bh = total_h + pad_y * 2
    y0 = img.height - 78 - bh                    # zona aman bawah, posisi TETAP
    ov = Image.new('RGBA', img.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    od.rounded_rectangle([cx - bw/2, y0, cx + bw/2, y0 + bh], radius=26,
                         fill=(10, 12, 18, int(0.74 * alpha)))
    tcol = AMBER + (alpha,) if style == 'warn' else (255, 255, 255, alpha)
    for i, t in enumerate(lines):
        w_ = od.textlength(t, font=f)
        od.text((cx - w_/2, y0 + pad_y + i*lh), t, font=f, fill=tcol)
    return Image.alpha_composite(img.convert('RGBA'), ov).convert('RGB')

def chunk_text(text, max_words=5):
    """potong kalimat jadi potongan kinetik"""
    words = text.replace('"', '').split()
    chunks, cur = [], []
    for w_ in words:
        cur.append(w_)
        if len(cur) >= max_words or w_.endswith((',', '.', '!', '?', ':', ';')):
            chunks.append(' '.join(cur)); cur = []
    if cur: chunks.append(' '.join(cur))
    return chunks
