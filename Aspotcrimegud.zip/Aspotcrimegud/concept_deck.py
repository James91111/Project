#!/usr/bin/env python3
# ============================================================
#  CONCEPT DECK — 500 "Director's Concept" unik per episode.
#  Setiap konsep = ALUR (struktur cerita) + GERAK (bahasa gerak
#  karakter) + CAMERA (ritme potongan) + STAGING (warna emosional
#  adegan) + PROP-MOTION. Kombinasi dijamin unik & tak beruntun.
# ============================================================
import random

N_CONCEPTS = 500

ALUR = [
 ('CHRONO', 'Tell the events in strict order, from the first ring to the aftermath.'),
 ('REWIND', 'Open at the moment of the loss, then rewind and walk forward through how it happened.'),
 ('INMEDIAS', 'Start inside the peak of the crisis; reveal the background only in small pieces.'),
 ('PARALLEL', 'Follow two different victims of the same scam and let their stories meet at the end.'),
 ('CASEFILE', 'Structure the episode as a detective case file: evidence one, evidence two, conclusion.'),
 ('SCRIPT', 'Read the scammer own script line by line, and dismantle each line right after it.'),
 ('DIARY', 'Tell it as short dated diary entries written by the victim.'),
 ('LESSON', 'A grandparent explains it to a grandchild, in simple questions and gentle answers.'),
 ('MYTHS', 'Begin with what people wrongly believe, then disprove each belief one by one.'),
 ('COUNTDOWN', 'Rank the scam moves from mild to cruel, saving the cruelest for last.'),
 ('BRANCHES', 'At every decision point show the dangerous choice first, then the safe choice.'),
 ('AFTERMATH', 'Look back one year later: what changed, what healed, what the victim knows now.'),
 ('TRIAL', 'Structure it as courtroom testimony, with calm flashbacks to each scene.'),
 ('BULLETIN', 'A calm live news bulletin: update one, update two, and a closing summary.'),
 ('CHECKLIST', 'Build a five point defense checklist together, one point per story beat.'),
 ('GOSSIP', 'A caring neighbor retells the whole story, warm, detailed, and human.'),
 ('TRANSCRIPT', 'Unfold the episode like a phone call transcript, with your commentary between lines.'),
 ('PLAYBOOK', 'Show the scammer playbook from the inside first, then how each step is broken.'),
 ('QUIZ', 'Ask the viewer to guess what happens next before every reveal, then answer it.'),
 ('LETTER', 'Open with a letter or email in hand, and unpack it paragraph by paragraph.'),
]

MOTION = [
 ('PACE', 'victim@pace', ['she paced the kitchen', 'he paced the small hallway'],
  'the victim paces slowly while the call continues'),
 ('SINK', 'victim@hurt', ['she sank into the chair', 'he sat down very slowly'],
  'at the loss moment the character sinks down slowly'),
 ('FREEZE', 'victim', ['everything went quiet', 'for a second nobody moved'],
  'freeze the world for one beat at the big reveal'),
 ('TURN', 'victim', ['she turned to face the room', 'he looked straight ahead'],
  'on THE FIX the character turns toward the viewer'),
 ('ENTER', 'scammer@enter', ['the door opened slowly', 'a stranger stepped inside'],
  'the wrong person enters the frame on first appearance'),
 ('SHAKE', 'victim@hurt', ['her hands would not stop shaking', 'his knees felt thin'],
  'a small stagger on every red flag'),
 ('MIRROR', 'victim', ['they both reached for the phone', 'two hands, same tremble'],
  'two characters mirror each other in the parallel scenes'),
 ('POINT', 'victim', ['she pointed at the numbers', 'he pointed at the chart'],
  'the character points whenever a number or stat appears'),
 ('CLUTCH', 'victim', ['she clutched the old photo', 'he held the wallet like a memory'],
  'the victim clutches one personal object during emotional beats'),
 ('WAVE', 'victim', ['she gestured with both hands', 'he waved it off at first'],
  'gentle hand gestures while explaining, calm and human'),
]

CAMERA = [
 ('LONGTAKE', 'Calm long scenes; cut only when the location changes.'),
 ('FASTCUT', 'Quick cuts every sentence during the scam moves, slower during the fix.'),
 ('SLOWIN', 'The first three scenes are slow and quiet, then the rhythm speeds up.'),
 ('PUNCH', 'After every big number, one short one-sentence paragraph alone.'),
 ('BREATHE', 'Between heavy sections, one quiet sentence that only paints the room.'),
]

STAGING = [
 ('TEARS', 'One honest tear moment is allowed; keep it brief and dignified.'),
 ('STEADY', 'No crying; show quiet strength and a steady breath instead.'),
 ('WARM', 'Warm details in the room: tea, a cat, a knitted blanket.'),
 ('COLD', 'Cold details: night, fluorescent light, an empty street.'),
 ('FAMILY', 'A family member appears in exactly one scene, at the turning point.'),
 ('ALONE', 'The victim is fully alone until the helper arrives near the end.'),
 ('HUMOR', 'One gentle human humor beat, never at the victim, always kind.'),
 ('SILENCE', 'Use sound as tension: a ticking clock, a ringtone, a kettle.'),
 ('OBJECTS', 'Let objects carry the story: an unanswered phone, an open envelope.'),
 ('WEATHER', 'Weather mirrors the mood: rain at the loss, sun at the fix.'),
 ('SCREENS', 'The story unfolds through glowing screens: phone, TV, laptop light on faces.'),
 ('PAPER', 'Paper tells the story: statements, letters, receipts handled on camera.'),
]

PROPM = [
 ('SPIN', 'spin first, pulse later'),
 ('PULSE', 'pulse first, float later'),
 ('FLOAT', 'float first, pop later'),
 ('POP', 'pop first, spin later'),
 ('DROP', 'drop at the loss, float at the fix'),
]


def get_concept(cn):
    # pemetaan injektif: (alur, camera, propm) mengkode posisi secara unik,
    # jadi 500 konsep dijamin unik satu sama lain.
    # Permutasi (n*211 mod 500) membuat episode BERURUTAN mendapat
    # alur/kamera/prop yang ACAK — tidak ada pola berulang yang berdekatan.
    n = ((int(cn) - 1) % N_CONCEPTS)
    idx = (n * 211) % N_CONCEPTS     # gcd(211,500)=1 -> permutasi sempurna
    a = ALUR[idx % 20]
    c = CAMERA[(idx // 20) % 5]
    p = PROPM[idx // 100]            # 20*5*5 = 500 -> injektif penuh
    s = STAGING[(n * 7) % len(STAGING)]   # berubah tiap episode (gcd 7,12 = 1)
    m = MOTION[(n * 5) % len(MOTION)]     # berubah tiap episode (gcd 5,12 = 1)
    return dict(id=n + 1, alur=a, motion=m, camera=c, staging=s, propm=p)


def concept_block(cn):
    t = get_concept(cn)
    L = ['=== EPISODE CONCEPT C-%03d (this episode DIRECTING plan - follow it) ===' % t['id']]
    L += ['STORY FLOW (%s): %s' % (t['alur'][0], t['alur'][1]),
          'CHARACTER MOVEMENT (%s): %s.' % (t['motion'][0], t['motion'][3]),
          '  Weave these two movement phrases naturally, each once, in different paragraphs:',
          '    - %s' % t['motion'][2][0],
          '    - %s' % t['motion'][2][1],
          'CAMERA RHYTHM (%s): %s' % (t['camera'][0], t['camera'][1]),
          'STAGING (%s): %s' % (t['staging'][0], t['staging'][1]),
          'PROP MOTION (%s): props should %s.' % (t['propm'][0], t['propm'][1]),
          'No episode may feel like another: this concept is unique to this episode.']
    return '\n'.join(L)
