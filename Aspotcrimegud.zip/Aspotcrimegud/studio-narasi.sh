#!/bin/bash
# SPOT THE SCAM Studio + SUB-HALAMAN PROMPT NARASI
# Launcher BARU — file lama (studio.py / studio-app.sh) TIDAK diubah.
# Studio utama : http://localhost:8808/
# Prompt narasi: http://localhost:8808/narasi
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONUNBUFFERED=1
exec python3 "$DIR/promptnarasi.py"
