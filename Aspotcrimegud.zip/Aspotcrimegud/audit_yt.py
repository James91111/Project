# -*- coding: utf-8 -*-
"""
audit_yt.py — Cross-check "Generic or Repetitive Content" (kebijakan YPP YouTube)
=================================================================================
Simulasi pemeriksaan ala reviewer YouTube terhadap sistem Spot The Scam:
  A. SISI NARASI  : kombinasi variabel anti-duplikat lintas batch, aturan anti-opening berulang
  B. SISI VISUAL  : 500 blok VISUAL DIRECTION, 500 blok KONSEP, 500 tanda template unik
  C. BUKTI PIKSEL : frame episode pra-render diuji pairwise (harus beda, bukan sekadar resep beda)

Jalankan:  python3 audit_yt.py
Keluar dengan kode 0 bila LULUS semua, 1 bila ada yang gagal.
"""
import hashlib, os, random, sys

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
sys.path.insert(0, BASE)

HASIL = []   # (nama, status, detail)

def catat(nama, lulus, detail):
    HASIL.append((nama, lulus, detail))
    print(('  [LULUS] ' if lulus else '  [GAGAL] ') + nama + ' — ' + detail)

# ============================================================ A. NARASI
print('\n=== A. SISI NARASI ===')
import promptnarasi as pn

# A1. simulasi 20 batch x 25 episode: tidak boleh ada kombinasi variabel kembar.
# assign_batch() sendiri yang mendaftarkan ke `used`; bila ada duplikat,
# isi set akan lebih sedikit dari 500.
used, prev, total = set(), None, 0
for batch in range(20):
    combos = pn.assign_batch('audit-%d' % batch, 25, prev, used)
    total += len(combos)
    prev = combos[-1]
catat('A1 kombinasi variabel 500 episode (20 batch) unik',
      total == 500 and len(used) == 500,
      '%d kombinasi dihasilkan, %d unik di log' % (total, len(used)))

# A2. aturan anti-opening berulang tertanam di prompt
contoh = pn.build_prompt(pn.load_base_prompt(), 99,
                         {'title': 'test', 'angle': '', 'facts': 'x'},
                         pn.assign_batch('x', 1, None, set())[0], '', ['Opening A', 'Opening B'], True)
ada_larangan = 'Do NOT start like any of these previous episode openings' in contoh
ada_retensi  = 'RETENTION: first sentence under 12 words' in contoh
ada_tags     = 'UNIQUE 3-4 sentence video description' in contoh
catat('A2 prompt memaksa opening beda dari 5 episode sebelumnya', ada_larangan,
      'blok larangan opening ditemukan' if ada_larangan else 'TIDAK ADA')
catat('A3 prompt memaksa hook retensi detik pertama', ada_retensi,
      'aturan 12 kata + mini-cliffhanger' if ada_retensi else 'TIDAK ADA')
catat('A4 deskripsi & tag wajib unik per episode', ada_tags,
      'aturan deskripsi unik ditemukan' if ada_tags else 'TIDAK ADA')

# A5. aturan struktur naskah (anti "slide teks tanpa narasi")
b = pn.load_base_prompt()
struktur_ok = all(k in b for k in ['1,550', '15 words', '25', '32'])
catat('A5 aturan naskah penuh (bukan slideshow): 1.550-1.700 kata, 25-32 paragraf',
      struktur_ok, 'semua aturan panjang naskah ada di base prompt' if struktur_ok else 'ada yang hilang')

# ============================================================ B. VISUAL (teks)
print('\n=== B. SISI VISUAL (500 template) ===')
import visual_deck as vd
import concept_deck as cd

vhash, chash, tanda, masalah = set(), set(), set(), []
for n in range(1, vd.N_TEMPLATES + 1):
    vb = vd.visual_block(n)
    cb = cd.concept_block(n)
    t  = vd.get_template(n)
    hv, hc = hashlib.md5(vb.encode()).hexdigest(), hashlib.md5(cb.encode()).hexdigest()
    if hv in vhash: masalah.append('VISUAL duplikat ep%d' % n)
    if hc in chash: masalah.append('KONSEP duplikat ep%d' % n)
    vhash.add(hv); chash.add(hc)
    tanda.add((t['bg'], t['actors'], t['props'], tuple(t['furni']), t['key']))
catat('B1 500 blok VISUAL DIRECTION unik', len(vhash) == 500,
      '%d unik' % len(vhash) if not masalah else '; '.join(masalah[:3]))
catat('B2 500 blok KONSEP (gerak/alur/kamera/staging) unik', len(chash) == 500,
      '%d unik' % len(chash))
catat('B3 500 tanda template (latar+aktor+prop+furni) unik', len(tanda) == 500,
      '%d unik' % len(tanda))
latar = {vd.get_template(n)['bg'] for n in range(1, 501)}
catat('B4 500 latar berbeda, tanpa daur ulang frame', len(latar) == 500,
      '%d latar unik (vk001-vk500)' % len(latar))

# ============================================================ C. BUKTI PIKSEL
print('\n=== C. BUKTI PIKSEL (bukan cuma resep — gambarnya benar-benar beda) ===')
from PIL import Image
sampel = [1, 2, 26, 27, 60, 100, 140, 200, 260, 320, 400, 460]
img, paths = {}, []
for n in sampel:
    p = '/tmp/audit_ep%03d.png' % n
    vd.build_preview(n, p)
    img[n] = Image.open(p).convert('L').resize((8, 8))
    paths.append(p)

def phash(im):
    px = list(im.getdata())
    r = sum(px) / 64.0
    return ''.join('1' if v > r else '0' for v in px)

hashes = [phash(img[n]) for n in sampel]
unik = len(set(hashes))
catat('C1 perceptual-hash frame: semua berbeda', unik == len(sampel),
      '%d/%d hash unik' % (unik, len(sampel)))

def beda(a, b):
    pa, pb = img[a].getdata(), img[b].getdata()
    return sum(abs(x - y) for x, y in zip(pa, pb)) / 64.0

pair_min = min(beda(sampel[i], sampel[i + 1]) for i in range(len(sampel) - 1))
catat('C2 beda piksel rata-rata antar episode berurutan', pair_min > 2.0,
      'minimum %.1f/255 (ambang 2.0)' % pair_min)

# ============================================================ KEPUTUSAN
gagal = [h for h in HASIL if not h[1]]
print('\n' + '=' * 60)
if gagal:
    print('PUTUSAN: TIDAK LULUS — %d pemeriksaan gagal:' % len(gagal))
    for n, _, d in gagal:
        print('  ✘', n, ':', d)
    sys.exit(1)
print('PUTUSAN: LULUS ✔  (%d/%d pemeriksaan)' % (len(HASIL), len(HASIL)))
print('Sistem menghasilkan konten yang TIDAK template-clone:')
print('  narasi dipaksa beda (opening, variabel, hook), visual 500/500 unik')
print('  dan terbukti berbeda sampai tingkat piksel.')
sys.exit(0)
