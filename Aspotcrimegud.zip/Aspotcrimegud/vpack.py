#!/usr/bin/env python3
# ============================================================
#  VPACK — paket aset BARU untuk 500 template visual:
#   * 500 resep latar unik      (didaftarkan ke bgpack)
#   * 30 preset karakter baru   (didaftarkan ke cast.PRESET)
#   * 10 objek sprite baru      (objpack: PNG + manifest)
#   * 36 furnitur baru          (furnipack: PNG)
#   * skema furnitur per-template (didaftarkan ke stage.SKEMA_V40)
#  Semua hook bersifat ADITIF & aman gagal (try/except).
# ============================================================
import os, json, random
from PIL import Image, ImageDraw

BASE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(BASE, 'assets')
INK = (30, 34, 58)
NAVY, TEAL, CREAM, OLIVE, RED, GRAY = (30, 46, 92), (88, 134, 126), \
    (240, 232, 214), (122, 128, 84), (198, 96, 84), (163, 167, 178)
COLS = dict(navy=NAVY, teal=TEAL, cream=CREAM)

# ---------------- 1) 500 resep latar unik ----------------
_BASES = ['plain', 'dots', 'grid', 'stripes', 'arc', 'meadow',
          'tiles', 'panels', 'archwin', 'citysky', 'road']
_DECOS = ['none', 'bush', 'flowers', 'tree', 'pine', 'grass', 'lamppost',
          'bench', 'fence', 'signpost', 'mailbox', 'sun', 'clouds', 'plant',
          'frame', 'book', 'star', 'mug', 'radio', 'arrow', 'cross',
          'pillars', 'scales', 'plane', 'board', 'shelf', 'lights', 'cart',
          'bigscreen']
_PALS = ['ivory', 'sky', 'mint', 'blush', 'sand',
         'clinical', 'wood', 'terminal', 'store', 'dusk']

def gen_bg_recipes(n=500):
    out, seen = [], set()
    for i in range(1, n + 1):
        rng = random.Random('vkbg%04d' % i)
        while True:
            key = (rng.choice(_BASES), rng.choice(_DECOS), rng.choice(_PALS))
            if key not in seen:
                seen.add(key)
                break
        out.append(('vk%03d' % i, key[0], key[1], key[2]))
    return out

BG_RECIPES = gen_bg_recipes()

def register_bg(g):
    for r in BG_RECIPES:
        if r[0] not in g['NAMES']:
            g['RECIPES'].append(r)
            g['NAMES'].append(r[0])

# ---------------- 2) preset karakter baru ----------------
NEW_CAST = {
 'ruth':   dict(skin='light', hair='bun',   hcol='white', glasses=True,  accent=(150, 112, 142), cane=True, emo='neutral'),
 'walter': dict(skin='light', hair='sides', hcol='white', mustache=True, accent=(110, 126, 154), emo='neutral'),
 'doris':  dict(skin='brown', hair='curls', hcol='gray',  glasses=True,  accent=(240, 190, 70), emo='happy'),
 'earl':   dict(skin='brown', hair='short', hcol='gray',  hat='police',  accent=(122, 128, 84), belt=True, emo='stern'),
 'mabel':  dict(skin='tan',   hair='bun',   hcol='dark',  glasses=True,  accent=(88, 134, 126), emo='neutral'),
 'hank':   dict(skin='light', hair='beanie', hcol=(70, 90, 60), mustache=True, accent=(122, 128, 84), emo='neutral'),
 'rosa':   dict(skin='tan',   hair='long',  hcol='dark',  accent=(198, 96, 84), emo='happy'),
 'stan':   dict(skin='light', hair='sides', hcol='gray',  glasses=True,  suit=True, emo='stern'),
 'pearl':  dict(skin='deep',  hair='bun',   hcol='white', glasses=True,  accent=(150, 112, 142), cane=True, emo='neutral'),
 'gus':    dict(skin='deep',  hair='short', hcol='dark',  mustache=True, vest=True, emo='neutral'),
 'vera':   dict(skin='light', hair='curls', hcol='red',   glasses=True,  accent=(88, 134, 126), emo='happy'),
 'loyd':   dict(skin='tan',   hair='sides', hcol='white', mustache=True, cane=True, accent=(30, 46, 92), emo='neutral'),
 'iris':   dict(skin='brown', hair='long',  hcol='dark',  accent=(240, 190, 70), emo='happy'),
 'bud':    dict(skin='light', hair='beanie', hcol=(40, 44, 64), headset=True, shades=True, emo='sly'),
 'nora':   dict(skin='tan',   hair='bun',   hcol='gray',  coat=True, steth=True, emo='neutral'),
 'amos':   dict(skin='deep',  hair='sides', hcol='white', glasses=True,  suit=True, emo='stern'),
 'tess':   dict(skin='light', hair='long',  hcol='brown', accent=(198, 96, 84), emo='happy'),
 'rex':    dict(skin='tan',   hair='hood',  hcol=(90, 52, 48), headset=True, shades=True, emo='sly'),
 'opal':   dict(skin='light', hair='bun',   hcol='white', glasses=False, accent=(122, 128, 84), cane=True, emo='neutral'),
 'sid':    dict(skin='light', hair='short', hcol='gray',  vest=True, emo='neutral'),
 'fox':    dict(skin='light', hair='hood',  hcol=(52, 56, 76), headset=True, shades=True, emo='sly'),
 'viper':  dict(skin='tan',   hair='beanie', hcol=(60, 44, 70), headset=True, shades=True, emo='sly'),
 'crow':   dict(skin='brown', hair='hood',  hcol=(40, 44, 64), headset=True, shades=True, emo='sly'),
 'mailman':  dict(skin='light', hair='short', hcol='brown', hat='police', accent=(70, 90, 140), belt=True, emo='happy'),
 'mechanic': dict(skin='tan', hair='beanie', hcol=(90, 60, 50), vest=True, emo='neutral'),
 'waitress': dict(skin='light', hair='bun', hcol='brown', accent=(198, 96, 84), emo='happy'),
 'gardener': dict(skin='brown', hair='short', hcol='gray', hat='police', accent=(122, 128, 84), emo='happy'),
 'librarian':dict(skin='light', hair='bun', hcol='gray', glasses=True, accent=(150, 112, 142), emo='neutral'),
 'pastor':   dict(skin='deep', hair='sides', hcol='dark', suit=True, emo='neutral'),
 'teller2':  dict(skin='tan', hair='long', hcol='dark', vest=True, emo='happy'),
}
NEW_VICTIMS = ['ruth', 'walter', 'doris', 'pearl', 'mabel', 'vera', 'opal', 'gus']
NEW_SCAMMERS = ['fox', 'viper', 'crow', 'bud', 'rex']

def register_cast(g):
    g['SKIN'].setdefault('deep', (110, 72, 48))
    for k, v in NEW_CAST.items():
        g['PRESET'].setdefault(k, v)

# ---------------- 3) objek sprite baru (objpack) ----------------
def _new_img():
    img = Image.new('RGBA', (360, 300), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)

def _draw_objs():
    d_ = {}
    img, d = _new_img();  # goldbar
    for i, (y, col) in enumerate(((150, (247, 178, 54)), (110, (250, 195, 90)), (70, (247, 178, 54)))):
        x0 = 70 + (i % 2) * 40
        d.polygon([(x0, y + 70), (x0 + 20, y), (x0 + 160, y), (x0 + 180, y + 70)],
                  fill=col, outline=INK, width=6)
    d_['v_goldbar'] = img
    img, d = _new_img()  # suitcase
    d.rounded_rectangle([60, 90, 300, 260], 22, fill=(140, 90, 60), outline=INK, width=7)
    d.rounded_rectangle([140, 50, 220, 95], 16, fill=None, outline=INK, width=8)
    d.line([120, 90, 120, 260], fill=INK, width=6); d.line([240, 90, 240, 260], fill=INK, width=6)
    d.rectangle([110, 160, 130, 190], fill=(240, 190, 70), outline=INK, width=5)
    d.rectangle([230, 160, 250, 190], fill=(240, 190, 70), outline=INK, width=5)
    d_['v_suitcase'] = img
    img, d = _new_img()  # deed
    d.rounded_rectangle([80, 40, 280, 270], 10, fill=(250, 248, 240), outline=INK, width=7)
    for y in (80, 110, 140, 170):
        d.line([105, y, 255, y], fill=(150, 156, 176), width=6)
    d.ellipse([200, 200, 250, 250], fill=(198, 96, 84), outline=INK, width=6)
    d.line([215, 245, 205, 280], fill=(198, 96, 84), width=8)
    d.line([235, 245, 245, 280], fill=(198, 96, 84), width=8)
    d_['v_deed'] = img
    img, d = _new_img()  # ring
    d.ellipse([110, 120, 250, 260], outline=(240, 190, 70), width=18)
    d.polygon([(180, 40), (220, 80), (180, 120), (140, 80)], fill=(190, 225, 240), outline=INK, width=6)
    d_['v_ring'] = img
    img, d = _new_img()  # pills
    d.rounded_rectangle([120, 90, 240, 270], 18, fill=(240, 244, 248), outline=INK, width=7)
    d.rounded_rectangle([130, 55, 230, 95], 10, fill=(198, 96, 84), outline=INK, width=6)
    d.rectangle([140, 140, 220, 210], fill=(250, 248, 240), outline=INK, width=5)
    d.line([152, 165, 208, 165], fill=(120, 128, 146), width=6)
    d.line([152, 185, 196, 185], fill=(120, 128, 146), width=6)
    d_['v_pills'] = img
    img, d = _new_img()  # calendar
    d.rounded_rectangle([70, 60, 290, 260], 12, fill=(250, 248, 240), outline=INK, width=7)
    d.rectangle([70, 60, 290, 105], fill=(198, 96, 84), outline=INK, width=6)
    for x in (110, 180, 250):
        d.line([x, 45, x, 75], fill=INK, width=8)
    for r in range(3):
        for c in range(4):
            d.rectangle([95 + c * 48, 125 + r * 42, 125 + c * 48, 152 + r * 42],
                        outline=(150, 156, 176), width=4)
    d.ellipse([188, 168, 222, 196], outline=(226, 54, 54), width=7)
    d_['v_calendar'] = img
    img, d = _new_img()  # photo
    d.rounded_rectangle([80, 50, 280, 250], 12, fill=(160, 122, 92), outline=INK, width=7)
    d.rectangle([105, 75, 255, 225], fill=(228, 236, 244), outline=INK, width=5)
    d.ellipse([135, 110, 175, 150], fill=(241, 215, 190), outline=INK, width=5)
    d.ellipse([190, 115, 226, 151], fill=(219, 175, 142), outline=INK, width=5)
    d.line([135, 190, 175, 155], fill=INK, width=6); d.line([190, 190, 226, 156], fill=INK, width=6)
    d_['v_photo'] = img
    img, d = _new_img()  # keys
    d.ellipse([90, 90, 170, 170], outline=(240, 190, 70), width=12)
    for ang, ln in (((150, 150), (250, 210)), ((160, 160), (230, 250))):
        d.line([ang[0], ang[1], ln[0], ln[1]], fill=(240, 190, 70), width=12)
        d.line([ln[0], ln[1], ln[0] + 25, ln[1]], fill=(240, 190, 70), width=10)
    d_['v_keys'] = img
    img, d = _new_img()  # umbrella
    d.pieslice([60, 40, 300, 200], 180, 360, fill=(198, 96, 84), outline=INK, width=7)
    d.line([180, 120, 180, 250], fill=INK, width=9)
    d.arc([160, 230, 200, 270], 0, 180, fill=INK, width=9)
    d_['v_umbrella'] = img
    img, d = _new_img()  # coffee
    d.rounded_rectangle([110, 120, 250, 260], 18, fill=(240, 232, 214), outline=INK, width=7)
    d.arc([250, 150, 300, 230], -70, 70, fill=INK, width=9)
    for x in (150, 180, 210):
        d.arc([x - 12, 60, x + 12, 110], 90, 270, fill=(150, 156, 176), width=6)
    d_['v_coffee'] = img
    img, d = _new_img()  # contract
    d.rounded_rectangle([90, 40, 270, 270], 8, fill=(250, 248, 240), outline=INK, width=7)
    for y in (80, 110, 140, 170, 200):
        d.line([112, y, 248, y], fill=(150, 156, 176), width=5)
    d.line([112, 235, 190, 228], fill=INK, width=6)
    d.line([215, 210, 250, 245], fill=(30, 46, 92), width=8)
    d_['v_contract'] = img
    img, d = _new_img()  # badge
    d.polygon([(180, 40), (250, 70), (250, 150), (180, 250), (110, 150), (110, 70)],
              fill=(240, 190, 70), outline=INK, width=7)
    d.ellipse([150, 100, 210, 160], fill=(250, 248, 240), outline=INK, width=6)
    d.ellipse([168, 118, 192, 142], fill=(30, 46, 92))
    d.line([140, 190, 220, 190], fill=INK, width=7)
    d_['v_badge'] = img
    img, d = _new_img()  # ticket
    d.rounded_rectangle([60, 100, 300, 210], 14, fill=(88, 134, 126), outline=INK, width=7)
    d.line([230, 100, 230, 210], fill=INK, width=6, )
    for x in (230,):
        for y in range(110, 205, 20):
            d.line([x - 4, y, x + 4, y], fill=(250, 248, 240), width=5)
    d.line([85, 135, 205, 135], fill=(250, 248, 240), width=8)
    d.line([85, 165, 175, 165], fill=(250, 248, 240), width=6)
    d_['v_ticket'] = img
    img, d = _new_img()  # box
    d.polygon([(80, 120), (180, 90), (280, 120), (180, 150)], fill=(222, 190, 140), outline=INK, width=6)
    d.polygon([(80, 120), (180, 150), (180, 260), (80, 230)], fill=(198, 162, 112), outline=INK, width=6)
    d.polygon([(280, 120), (180, 150), (180, 260), (280, 230)], fill=(210, 176, 126), outline=INK, width=6)
    d.line([180, 90, 180, 150], fill=INK, width=5)
    d_['v_box'] = img
    img, d = _new_img()  # ladder
    d.line([130, 40, 110, 270], fill=INK, width=9)
    d.line([230, 40, 250, 270], fill=INK, width=9)
    for y in (80, 125, 170, 215, 255):
        k = (y - 40) / 230
        d.line([130 - 20 * k, y, 230 + 20 * k, y], fill=(240, 190, 70), width=8)
    d_['v_ladder'] = img
    img, d = _new_img()  # check
    d.rounded_rectangle([50, 90, 310, 220], 8, fill=(240, 244, 248), outline=INK, width=6)
    d.line([70, 125, 170, 125], fill=(120, 128, 146), width=6)
    d.line([230, 120, 290, 120], fill=(120, 128, 146), width=5)
    d.line([70, 160, 250, 160], fill=(30, 46, 92), width=7)
    d.line([70, 190, 150, 190], fill=(120, 128, 146), width=5)
    d_['v_check'] = img
    img, d = _new_img()  # heart
    d.polygon([(180, 250), (90, 160), (90, 100), (130, 70), (180, 110), (230, 70),
               (270, 100), (270, 160)], fill=(198, 96, 84), outline=INK, width=7)
    d_['v_heart'] = img
    return d_

OBJ_NEW = ['v_goldbar', 'v_suitcase', 'v_deed', 'v_ring', 'v_pills',
           'v_calendar', 'v_photo', 'v_keys', 'v_umbrella', 'v_coffee',
           'v_contract', 'v_badge', 'v_ticket', 'v_box', 'v_ladder',
           'v_check', 'v_heart']

def ensure_objpack():
    od = os.path.join(ASSETS, 'objpack')
    man_p = os.path.join(od, 'manifest.json')
    man = json.load(open(man_p, encoding='utf-8'))
    have = {v['name'] for v in man.values()}
    drew = None
    added = 0
    for i, name in enumerate(OBJ_NEW, 1):
        if name in have:
            continue
        if drew is None:
            drew = _draw_objs()
        fn = 'obj_v%02d.png' % i
        drew[name].save(os.path.join(od, fn))
        man[fn] = {'name': name, 'cat': 'vpack'}
        added += 1
    if added:
        json.dump(man, open(man_p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    return added

# ---------------- 4) furnitur baru (furnipack) ----------------
def _draw_furni():
    out = {}
    for cn, col in COLS.items():
        img, d = _new_img()  # sofa
        d.rounded_rectangle([20, 120, 340, 240], 20, fill=col, outline=INK, width=6)
        d.rounded_rectangle([20, 60, 70, 200], 16, fill=col, outline=INK, width=6)
        d.rounded_rectangle([290, 60, 340, 200], 16, fill=col, outline=INK, width=6)
        d.line([120, 130, 120, 200], fill=INK, width=5); d.line([240, 130, 240, 200], fill=INK, width=5)
        d.line([40, 240, 40, 280], fill=INK, width=8); d.line([320, 240, 320, 280], fill=INK, width=8)
        out['sofa_' + cn] = img
        img, d = _new_img()  # armchair
        d.rounded_rectangle([70, 110, 290, 240], 20, fill=col, outline=INK, width=6)
        d.rounded_rectangle([70, 50, 115, 190], 16, fill=col, outline=INK, width=6)
        d.rounded_rectangle([245, 50, 290, 190], 16, fill=col, outline=INK, width=6)
        d.line([90, 240, 90, 280], fill=INK, width=8); d.line([270, 240, 270, 280], fill=INK, width=8)
        out['armchair_' + cn] = img
        img, d = _new_img()  # fridge
        d.rounded_rectangle([110, 20, 250, 280], 12, fill=col, outline=INK, width=6)
        d.line([110, 120, 250, 120], fill=INK, width=6)
        d.line([225, 60, 225, 105], fill=INK, width=8); d.line([225, 140, 225, 200], fill=INK, width=8)
        out['fridge_' + cn] = img
        img, d = _new_img()  # stove
        d.rounded_rectangle([60, 100, 300, 280], 10, fill=col, outline=INK, width=6)
        for x in (110, 180, 250):
            d.ellipse([x - 22, 78, x + 22, 108], outline=INK, width=6)
        d.rectangle([90, 150, 270, 250], outline=INK, width=6)
        d.line([90, 165, 270, 165], fill=INK, width=6)
        out['stove_' + cn] = img
        img, d = _new_img()  # bookshelf
        d.rectangle([80, 30, 280, 280], outline=INK, width=6)
        for y in (110, 190):
            d.line([80, y, 280, y], fill=INK, width=6)
        for y0 in (45, 125, 205):
            for x in range(95, 260, 34):
                h = 48 if (x // 34) % 2 else 56
                d.rectangle([x, y0 + 62 - h, x + 20, y0 + 62], fill=col, outline=INK, width=4)
        out['bookshelf_' + cn] = img
        img, d = _new_img()  # floorlamp
        d.polygon([(130, 40), (230, 40), (250, 110), (110, 110)], fill=col, outline=INK, width=6)
        d.line([180, 110, 180, 260], fill=INK, width=8)
        d.line([130, 270, 230, 270], fill=INK, width=9)
        out['floorlamp_' + cn] = img
        img, d = _new_img()  # tvset
        d.rounded_rectangle([60, 40, 300, 180], 12, fill=(30, 34, 58), outline=INK, width=6)
        d.rounded_rectangle([75, 55, 285, 165], 8, fill=col, outline=INK, width=4)
        d.line([180, 180, 180, 230], fill=INK, width=8)
        d.rounded_rectangle([90, 230, 270, 275], 10, fill=col, outline=INK, width=6)
        out['tvset_' + cn] = img
        img, d = _new_img()  # sidetable
        d.ellipse([60, 90, 300, 150], fill=col, outline=INK, width=6)
        d.line([110, 140, 100, 270], fill=INK, width=8); d.line([250, 140, 260, 270], fill=INK, width=8)
        out['sidetable_' + cn] = img
        img, d = _new_img()  # benchwood
        d.rounded_rectangle([40, 150, 320, 190], 10, fill=col, outline=INK, width=6)
        d.rounded_rectangle([40, 80, 320, 110], 10, fill=col, outline=INK, width=6)
        d.line([70, 190, 70, 270], fill=INK, width=8); d.line([290, 190, 290, 270], fill=INK, width=8)
        d.line([70, 110, 70, 150], fill=INK, width=7); d.line([290, 110, 290, 150], fill=INK, width=7)
        out['benchwood_' + cn] = img
        img, d = _new_img()  # picket
        for x in (60, 130, 200, 270):
            d.polygon([(x, 260), (x, 100), (x + 25, 70), (x + 50, 100), (x + 50, 260)],
                      fill=col, outline=INK, width=5)
        d.line([40, 140, 320, 140], fill=INK, width=7); d.line([40, 210, 320, 210], fill=INK, width=7)
        out['picket_' + cn] = img
        img, d = _new_img()  # plantpot
        d.polygon([(120, 160), (240, 160), (220, 270), (140, 270)], fill=col, outline=INK, width=6)
        for px, py in ((150, 110), (180, 80), (210, 110), (165, 130), (195, 130)):
            d.ellipse([px - 22, py - 22, px + 22, py + 22], fill=(150, 196, 150), outline=INK, width=5)
        out['plantpot_' + cn] = img
        img, d = _new_img()  # clockwall
        d.ellipse([90, 40, 270, 220], fill=(250, 248, 240), outline=INK, width=8)
        d.line([180, 130, 180, 70], fill=INK, width=8); d.line([180, 130, 230, 150], fill=INK, width=7)
        d.line([180, 220, 180, 260], fill=col, width=9)
        out['clockwall_' + cn] = img
        img, d = _new_img()  # wardrobe
        d.rounded_rectangle([100, 30, 260, 270], 10, fill=col, outline=INK, width=6)
        d.line([180, 30, 180, 270], fill=INK, width=6)
        d.ellipse([166, 140, 176, 150], fill=INK); d.ellipse([184, 140, 194, 150], fill=INK)
        d.line([120, 270, 120, 285], fill=INK, width=7); d.line([240, 270, 240, 285], fill=INK, width=7)
        out['wardrobe_' + cn] = img
        img, d = _new_img()  # dining
        d.ellipse([50, 130, 310, 190], fill=col, outline=INK, width=6)
        d.line([90, 180, 80, 270], fill=INK, width=8); d.line([270, 180, 280, 270], fill=INK, width=8)
        d.rounded_rectangle([20, 90, 60, 170], 8, fill=col, outline=INK, width=5)
        d.rounded_rectangle([300, 90, 340, 170], 8, fill=col, outline=INK, width=5)
        out['dining_' + cn] = img
        img, d = _new_img()  # podium
        d.polygon([(120, 60), (240, 60), (270, 120), (250, 270), (110, 270), (90, 120)],
                  fill=col, outline=INK, width=6)
        d.line([120, 60, 100, 40], fill=INK, width=7)
        d.ellipse([95, 25, 115, 45], fill=(30, 34, 58))
        d.rectangle([130, 100, 230, 150], outline=INK, width=5)
        out['podium_' + cn] = img
        img, d = _new_img()  # locker
        d.rectangle([90, 30, 270, 270], outline=INK, width=6)
        d.line([150, 30, 150, 270], fill=INK, width=6); d.line([210, 30, 210, 270], fill=INK, width=6)
        for x in (120, 180, 240):
            for y in (60, 85):
                d.line([x - 12, y, x + 12, y], fill=col, width=6)
            d.ellipse([x - 4, 150, x + 4, 158], fill=INK)
        out['locker_' + cn] = img
    return out

def ensure_furnipack():
    fd = os.path.join(ASSETS, 'furnipack')
    drew = None
    added = 0
    for name, img in _draw_furni().items():
        p = os.path.join(fd, name + '.png')
        if not os.path.exists(p):
            if drew is None:
                drew = True
            img.save(p)
            added += 1
    return added

FURNI_NEW = ['%s_%s' % (f, c) for f in
             ('sofa', 'armchair', 'fridge', 'stove', 'bookshelf', 'floorlamp',
              'tvset', 'sidetable', 'benchwood', 'picket', 'plantpot', 'clockwall',
              'wardrobe', 'dining', 'podium', 'locker')
             for c in COLS]

# ---------------- 6) pra-render 500 latar BARU jadi file PNG nyata ----------------
def ensure_bgpreviews():
    """Render 500 resep latar vk001-vk500 ke assets/vpackbg/*.png (960x540).
    Dijalankan sekali; file nyata = paket kaya & preview instan."""
    outd = os.path.join(ASSETS, 'vpackbg')
    os.makedirs(outd, exist_ok=True)
    import bgpack
    n = 0
    for r in BG_RECIPES:
        p = os.path.join(outd, r[0] + '.png')
        if os.path.exists(p):
            continue
        try:
            bgpack.render(r[0]).resize((960, 540)).save(p)
            bgpack._cache.clear()      # jaga memori: jangan simpan 500 frame
            n += 1
        except Exception:
            pass
    return n

# ---------------- 5) skema furnitur per template ----------------
def furni_for(tn, key):
    rng = random.Random('vkf%04d' % tn)
    pool = FURNI_NEW[:]
    old = ['plantbig_teal', 'rug_navy', 'window_cream', 'desk_wood',
           'counter_wood', 'chair_olive', 'roundtable_cream', 'cabinet_gray']
    n = 2 + tn % 2
    out, xs = [], [300, 950, 1550]
    for i in range(n):
        name = pool[(tn * 3 + i * 7) % len(pool)] if (tn + i) % 3 else old[(tn + i) % len(old)]
        out.append((name, xs[i], round(1.0 + ((tn + i) % 4) * 0.2, 2), i % 2 == 0))
    return out

try:
    ensure_objpack()
    ensure_furnipack()
except Exception:
    pass


def register_stage(g):
    import visual_deck as vd
    for tn in range(1, vd.N_TEMPLATES + 1):
        t = vd.get_template(tn)
        g['SKEMA_V40'][t['name']] = furni_for(tn, t['key'])
        # kunci: motif template -> latar BARU uniknya sendiri
        g['BG_BY_MOTIF'][t['name']] = t['bg']
    for v in NEW_VICTIMS:
        if v not in g['VICTIMS']:
            g['VICTIMS'].append(v)
    for s in NEW_SCAMMERS:
        if 'SCAMMERS' in g and s not in g['SCAMMERS']:
            g['SCAMMERS'].append(s)
