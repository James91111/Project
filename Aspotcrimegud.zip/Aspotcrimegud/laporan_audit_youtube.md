# LAPORAN AUDIT — Anti Konten Repetitif YouTube
**Spot The Scam** · dijalankan 2026-10-03 · `python3 audit_yt.py`

---

## 1. Apa syarat resmi YouTube?

Aturan yang relevan adalah kebijakan monetisasi YPP, riwayat namanya:

| Tanggal | Nama kebijakan | Isi |
|---|---|---|
| Sebelum Juli 2025 | *Repetitious content* | Konten mass-produced / berulang tidak dimonetisasi |
| 15 Juli 2025 | *Inauthentic content* | Penegasan + deteksi lebih baik untuk konten massal/repetitif |
| Juli 2026 | *Generic or Repetitive Content* | Diperluas jadi 3 kategori, penekanan anti "AI slop" |

Yang **dilarang** (sumber: kebijakan YPP via Social Media Today [1](https://www.socialmediatoday.com/news/youtube-clarifies-monetization-update-inauthentic-repeated-content/752892/), Sybrid [2](https://sybrid.com/resources/blog/youtube-monetization-updates-2025/), New Money Matrix [3](https://newmoneymatrix.org/youtube-inauthentic-content-policy-explained/)):

1. Video "dibuat dengan template, variasi sedikit atau tanpa variasi".
2. Cerita naratif yang antar-video hanya beda permukaan (*superficial differences*).
3. Slideshow / teks berjalan dengan narasi sama, tanpa nilai edukasi/hiburan.
4. Upload massal: hanya ganti judul/tanggal/nama, sisanya sama.

Yang **tetap boleh secara eksplisit**:

- Intro & outro sama di semua video (branding channel) [3].
- Seri dengan format tetap (karakter berulang, rubrik mingguan) [3].
- Channel tanpa wajah (*faceless*) dan alat bantu AI, **asal ada nilai orisinal**: riset, storytelling, edukasi [4](https://www.techdogs.com/td-articles/trending-stories/is-youtube-killing-the-faceless-channels-new-ai-policies-punish-faceless-creators) [5](https://milx.app/en/trends/should-you-use-ai-generated-videos-and-how-will-it-impact-youtube-monetization).

## 2. Hasil uji (trial & error)

Audit menjalankan 11 pemeriksaan; 1 pemeriksaan (A1) sempat gagal di percobaan pertama karena bug pada skrip auditnya sendiri (false positive), diperbaiki, lalu lulus. Tidak ada satu pun kegagalan yang berasal dari sistem produksinya.

| # | Pemeriksaan | Hasil |
|---|---|---|
| A1 | Kombinasi variabel narasi 500 episode (simulasi 20 batch × 25) — tidak ada yang kembar | ✅ 500/500 unik |
| A2 | Prompt memaksa opening berbeda dari 5 episode sebelumnya | ✅ |
| A3 | Hook retensi detik pertama diwajibkan (kalimat 1 < 12 kata + mini-cliffhanger) | ✅ |
| A4 | Deskripsi & tag wajib unik per episode (pola tidak boleh diulang) | ✅ |
| A5 | Naskah penuh 1.550–1.700 kata, 25–32 paragraf (bukan slideshow teks) | ✅ |
| B1 | 500 blok VISUAL DIRECTION pairwise unik (hash) | ✅ 500/500 |
| B2 | 500 blok KONSEP gerak/alur/kamera/staging pairwise unik | ✅ 500/500 |
| B3 | 500 tanda template (latar+aktor+prop+furni) unik | ✅ 500/500 |
| B4 | 500 latar berbeda (vk001–vk500), tanpa daur ulang frame | ✅ |
| C1 | Perceptual-hash frame hasil render: 12 sampel episode | ✅ 12/12 beda |
| C2 | Selisih piksel antar episode berurutan | ✅ min 14,5/255 (ambang 2,0) |

**PUTUSAN: LULUS 11/11** — output sistem tidak memenuhi definisi "template clone" YouTube: narasi dipaksa berbeda secara struktural, dan visual terbukti berbeda sampai tingkat piksel, bukan cuma resepnya yang berbeda.

## 3. Yang dijamin sistem vs yang tetap harus Anda lakukan

**Otomatis dijamin sistem:**
- Tidak ada dua episode yang memakai kombinasi variabel, template visual, latar, atau konsep sutradara yang sama.
- Pembuka episode tidak boleh meniru 5 episode terakhir.
- Latar belakang 500 file PNG berbeda — mustahil "slideshow dengan gambar sama".

**Wajib manual saat upload (ini tidak bisa diaudit dari sini):**
1. **Naskah akhir tetap direview manusia** sebelum rekam suara — sistem hanya memberi prompt, naskah jadi tanggung jawab kanal.
2. **Fakta hanya dari Anda** (FTC/FBI/AG negara bagian); jangan menyuruh AI mengarang angka — channel edukasi yang salah fakta berisiko lebih besar daripada isu repetitif.
3. **Disclosure konten sintetik**: kalau memakai suara AI yang terdengar nyata, centang "Altered content" di YouTube Studio [5]. Animasi stickman kartun tidak wajib disclosure.
4. **Jangan upload borongan** belasan video mirip dalam sehari — pola upload massal ikut dinilai [5].
5. **Judul & thumbnail divariasikan** per episode; jangan satu template thumbnail untuk semua video.
6. Pertahankan elemen yang memang diizinkan sama: intro/outro, karakter stickman, gaya narasi — itu branding, bukan pelanggaran [3].

## 4. Cara mengulang audit kapan saja

```bash
cd Aspotcrime
python3 audit_yt.py
```

Keluar kode 0 = lulus. Tambahkan episode baru tidak mengubah hasil: pemeriksaan berjalan terhadap sistemnya (500 template + generator kombinasi), bukan terhadap satu batch tertentu.
