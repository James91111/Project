#!/usr/bin/env python3
# ============================================================
#  VISUAL DECK — 500 template visual unik untuk Spot The Scam
#  Dibangun dari aset ASLI pipeline (bgpack 147, furnipack 129,
#  aktor & properti stage.py/cast.py) sehingga sintaks motif
#  yang dihasilkan PASTI valid dan langsung dipakai mesin.
# ============================================================
import os, json, random

BASE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(BASE, 'assets')
N_TEMPLATES = 500

import vpack, concept_deck

# ---------- aset nyata ----------
MANIFEST = json.load(open(os.path.join(ASSETS, 'bgpack', 'manifest.json')))
BG_BY_PAL = {}
for _f, _m in MANIFEST.items():
    BG_BY_PAL.setdefault(_m['palette'], []).append(_f)
FURNI = sorted(f[:-4] for f in os.listdir(os.path.join(ASSETS, 'furnipack'))
               if f.endswith('.png'))

PROPS_VALID = {'atm', 'blockphone', 'btc', 'car', 'card', 'checklist', 'clock',
               'counter', 'giftcards', 'heart', 'house', 'laptop', 'mail',
               'money', 'monitor', 'phone', 'report', 'shield', 'sign',
               'star', 'wallet'} | set(vpack.OBJ_NEW)
import cast as _castmod
ACTORS_VALID = set(_castmod.PRESET) | set(vpack.NEW_CAST)
LATAR_VALID = {'plain', 'clouds', 'trees', 'home', 'street', 'office', 'otomatis'}
ANIMS = ['pop', 'pulse', 'float', 'spin']

# ---------- 25 tema x 20 varian = 500 template ----------
THEMES = [
 dict(key='bank', title='Bank lobby', latar='office', pals=['wood', 'clinical'],
      furni=['counter_wood', 'plantbig_teal', 'chart_down'],
      actors=['victim;teller', 'victim;banker', 'victim;scammer', 'grandma;teller'],
      props=['card', 'money', 'wallet', 'counter'],
      kwsets=[['the teller window', 'inside the bank'],
              ['the branch manager', 'your savings account'],
              ['the bank lobby', 'a wire transfer']],
      flavors=['a slow morning, only two customers in line',
               'ten minutes before the branch closes',
               'the first day of the month, the queue is long',
               'a rainy afternoon, umbrellas by the door']),

 dict(key='atmcorner', title='ATM di sudut jalan', latar='street', pals=['sand', 'dusk'],
      furni=['atmbox_navy', 'streetlamp_gray'],
      actors=['victim;scammer', 'victim;caller', 'grandma;courier'],
      props=['atm', 'card', 'wallet'],
      kwsets=[['the cash machine', 'the atm screen'],
              ['the corner atm', 'withdraw the money'],
              ['the machine on the corner', 'your card in the slot']],
      flavors=['early morning, the street still empty',
               'a cold evening, breath visible in the air',
               'right after grocery shopping, bags in hand',
               'under a flickering streetlight']),

 dict(key='giftcards', title='Rak gift card', latar='plain', pals=['store'],
      furni=['shopcounter_teal', 'shelfgoods_olive'],
      actors=['victim;tech', 'victim;scammer', 'grandma;caller'],
      props=['giftcards', 'phone'],
      kwsets=[['the gift card rack', 'read the codes aloud'],
              ['gift cards from the rack', 'the cashier watched'],
              ['a handful of gift cards', 'the card numbers']],
      flavors=['a busy Saturday afternoon in the aisle',
               'the store is almost closing',
               'fluorescent lights, a long receipt in hand',
               'a kid watches curiously from the next aisle']),

 dict(key='crypto', title='Mesin crypto / komputer', latar='office', pals=['clinical', 'terminal'],
      furni=['pcdesk_dark', 'safebox_gray'],
      actors=['victim;tech', 'victim;scammer'],
      props=['btc', 'laptop', 'monitor'],
      kwsets=[['the crypto machine', 'a bitcoin wallet'],
              ['the wallet address', 'send it in crypto'],
              ['the machine at the store', 'the transaction hash']],
      flavors=['a glowing screen in a dim room',
               'a gas station kiosk, late at night',
               'the hum of a computer fan, midnight',
               'an unfamiliar app, big red letters']),

 dict(key='doorstep', title='Kurir di depan pintu', latar='home', pals=['ivory', 'sand'],
      furni=['door_wood', 'plantbig_teal', 'rug_red'],
      actors=['victim;courier', 'grandma;courier', 'victim;officer'],
      props=['mail', 'wallet', 'sign'],
      kwsets=[['a knock at the door', 'the courier'],
              ['a package for you', 'a man at the door'],
              ['the doorbell rang', 'a pickup code']],
      flavors=['a bright mid-morning, the garden quiet',
               'during her favorite show, an interruption',
               'a delivery van idling at the curb',
               'a stranger with a clipboard, smiling too wide']),

 dict(key='porchnight', title='Malam di teras', latar='home', pals=['dusk'],
      furni=['door_dark', 'streetlamp_dark'],
      actors=['grandma;courier', 'victim;scammer'],
      props=['phone', 'clock'],
      kwsets=[['late that night', 'the porch light'],
              ['past midnight', 'the doorbell again'],
              ['the front steps', 'a shadow at the door']],
      flavors=['the street is completely silent',
               'the clock shows 1 a.m.',
               'only the porch light is on',
               'the dog starts barking']),

 dict(key='kitchencall', title='Telepon di meja dapur', latar='home', pals=['ivory', 'blush'],
      furni=['roundtable_cream', 'window_cream'],
      actors=['grandma;grandpa', 'victim;caller'],
      props=['phone', 'clock'],
      kwsets=[['the kitchen table', 'her evening tea'],
              ['the phone on the counter', 'a cup of tea'],
              ['while dinner was cooking', 'the phone rang']],
      flavors=['the kettle just started to boil',
               'a crossword puzzle half finished',
               'the smell of soup on the stove',
               'afternoon sun through the window']),

 dict(key='bedroom2am', title='Kamar tidur jam 2 pagi', latar='home', pals=['blush', 'dusk'],
      furni=['bed_navy', 'bedside_teal', 'window_gray'],
      actors=['victim;caller', 'grandma;grandpa'],
      props=['phone', 'blockphone'],
      kwsets=[['two in the morning', 'the phone lit up'],
              ['woken by a ring', 'in the dark bedroom'],
              ['half asleep', 'an unknown number']],
      flavors=['the room is dark, only the screen glows',
               'the alarm clock shows 2:14',
               'glasses still on the nightstand',
               'heart beating fast before answering']),

 dict(key='callcenter', title='Ruang call center pelaku', latar='office', pals=['terminal', 'clinical'],
      furni=['desk_navy', 'pcdesk_dark', 'desk_dark'],
      actors=['victim;tech', 'victim;scammer'],
      props=['monitor', 'laptop', 'phone'],
      kwsets=[['the call center', 'a room full of screens'],
              ['rows of desks', 'reading from a script'],
              ['the operator', 'a headset and a list of numbers']],
      flavors=['dozens of voices talking at once',
               'a whiteboard with targets written on it',
               'somewhere far away, at the same hour',
               'the next number is already dialed']),

 dict(key='popup', title='Pop-up virus di layar', latar='office', pals=['terminal'],
      furni=['pcdesk_gray', 'desk_gray'],
      actors=['victim;tech'],
      props=['monitor', 'laptop', 'shield'],
      kwsets=[['a pop-up filled the screen', 'the virus warning'],
              ['the screen froze', 'a red warning box'],
              ['do not restart your computer', 'the number on the screen']],
      flavors=['in the middle of paying a bill',
               'while looking at family photos',
               'the cursor moves on its own',
               'a loud alarm sound from the speakers']),

 dict(key='police', title='Kantor polisi', latar='trees', pals=['mint'],
      furni=['desk_dark', 'courtbench_wood'],
      actors=['victim;cop', 'victim;officer'],
      props=['report', 'shield', 'sign'],
      kwsets=[['the police station', 'file a report'],
              ['the officer at the desk', 'a written statement'],
              ['the front desk sergeant', 'the detective said']],
      flavors=['a quiet weekday morning at the precinct',
               'fluorescent hallway, plastic chairs',
               'she brought a folder of printouts',
               'the officer listens, pen in hand']),

 dict(key='court', title='Ruang sidang', latar='office', pals=['wood'],
      furni=['judgebench_wood', 'witnessbox_wood', 'courtbench_dark'],
      actors=['victim;judge', 'victim;officer'],
      props=['report', 'checklist'],
      kwsets=[['the courtroom', 'the judge said'],
              ['in front of the judge', 'the case against the ring'],
              ['the guilty plea', 'the sentencing day']],
      flavors=['wooden benches, a full room',
               'the gavel has not fallen yet',
               'a folder of evidence on the table',
               'reporters waiting outside']),

 dict(key='hospital', title='Ruang rumah sakit', latar='office', pals=['clinical'],
      furni=['hospitalbed_teal', 'ivstand_teal', 'reception_gray'],
      actors=['victim;doctor', 'grandma;doctor'],
      props=['card', 'report', 'clock'],
      kwsets=[['the hospital room', 'a doctor in a hurry'],
              ['the emergency room', 'the nurse checked'],
              ['the clinic called', 'your test results']],
      flavors=['beeping monitors, white walls',
               'a paper gown and cold stethoscope',
               'waiting chairs outside the ward',
               'the bill arrives before the diagnosis']),

 dict(key='airport', title='Gerbang bandara', latar='plain', pals=['terminal'],
      furni=['depboard_teal', 'depseats_navy'],
      actors=['victim;agent', 'victim;scammer'],
      props=['sign', 'clock', 'wallet'],
      kwsets=[['the departure board', 'stuck at the airport'],
              ['the boarding gate', 'the flight was canceled'],
              ['a message from the airline', 'the baggage claim']],
      flavors=['announcements echo over the speakers',
               'a suitcase and a dying phone',
               'the gate number keeps changing',
               'hundreds of miles from home']),

 dict(key='store', title='Toko / kasir', latar='plain', pals=['store'],
      furni=['shopcounter_wood', 'shelfgoods_teal', 'flowerstand_cream'],
      actors=['victim;scammer', 'victim;neighbor'],
      props=['giftcards', 'card', 'wallet'],
      kwsets=[['the store counter', 'the cashier said'],
              ['at the checkout', 'the cashier asked twice'],
              ['the shop assistant', 'a warning from the register']],
      flavors=['a small town shop, the owner knows her',
               'a cashier who has seen this before',
               'a handwritten sign at the register',
               'bags packed, receipt in hand']),

 dict(key='busstop', title='Halte bus', latar='street', pals=['sky', 'sand'],
      furni=['busstop_red', 'streetlamp_gray'],
      actors=['victim;neighbor', 'victim;courier'],
      props=['phone', 'mail'],
      kwsets=[['the bus stop', 'waiting for the bus'],
              ['the bench at the stop', 'the route across town'],
              ['a stranger at the shelter', 'the bus was late']],
      flavors=['a windy afternoon, a folded newspaper',
               'the schedule is faded on the pole',
               'two strangers sharing the bench',
               'the bus appears around the corner']),

 dict(key='mailbox', title='Kotak surat', latar='street', pals=['mint', 'sky'],
      furni=['mailboxbig_red', 'gate_navy'],
      actors=['victim;courier', 'victim;neighbor'],
      props=['mail', 'checklist'],
      kwsets=[['the mailbox', 'the letter said'],
              ['an envelope in the mailbox', 'a certified letter'],
              ['the mail that morning', 'a check in the envelope']],
      flavors=['the flag on the mailbox is up',
               'bills and one thick envelope',
               'morning walk, slippers on the path',
               'the postman waves from the truck']),

 dict(key='gasstation', title='Pom bensin', latar='street', pals=['dusk', 'sand'],
      furni=['carside_red', 'streetlamp_dark'],
      actors=['victim;tech', 'victim;scammer'],
      props=['btc', 'car', 'phone'],
      kwsets=[['the gas station', 'the machine by the pumps'],
              ['a kiosk at the station', 'the clerk behind the glass'],
              ['the attendant asked', 'fuel and a strange request']],
      flavors=['the pumps glow under the canopy',
               'a long highway, few cars',
               'the clerk has seen this too',
               'night shift, coffee going cold']),

 dict(key='driveway', title='Mobil di halaman', latar='street', pals=['sand'],
      furni=['carside_navy', 'gate_gray'],
      actors=['victim;courier', 'victim;officer'],
      props=['car', 'wallet'],
      kwsets=[['the driveway', 'he drove off'],
              ['a car waiting outside', 'the engine still running'],
              ['the gray sedan', 'tires on the gravel']],
      flavors=['the neighbor peeks through the blinds',
               'the car is gone before the curtain drops',
               'an unfamiliar plate, dust settling',
               'she watches it turn the corner']),

 dict(key='toll', title='Gerbang tol / tagihan', latar='street', pals=['sky'],
      furni=['tollbooth_navy', 'railing_gray'],
      actors=['victim;officer'],
      props=['card', 'clock'],
      kwsets=[['the toll road', 'the text said your toll'],
              ['an unpaid toll', 'the transponder'],
              ['a fee from the turnpike', 'pay within 24 hours']],
      flavors=['the barrier arm stays down',
               'a message with a countdown',
               'rush hour, horns behind',
               'the link in the text looks almost real']),

 dict(key='taxoffice', title='Kantor pajak / SSA', latar='office', pals=['clinical', 'wood'],
      furni=['desk_dark', 'cabinet_gray'],
      actors=['victim;agent', 'victim;scammer'],
      props=['report', 'phone'],
      kwsets=[['the tax office', 'your social security number'],
              ['a letter from the agency', 'your file is flagged'],
              ['the office called', 'suspend your number']],
      flavors=['a government building, long corridors',
               'a waiting room with numbered tickets',
               'official letterhead, urgent tone',
               'a stamp, a signature, a warning']),

 dict(key='agentvisit', title='Agen datang ke rumah', latar='trees', pals=['mint'],
      furni=['desk_dark', 'courtbench_wood'],
      actors=['victim;agent'],
      props=['report', 'shield'],
      kwsets=[['two agents at the door', 'an official letter'],
              ['badges at the doorstep', 'they asked questions'],
              ['a visit from the bureau', 'a folder of evidence']],
      flavors=['they show identification slowly',
               'the living room goes quiet',
               'notes taken on a small pad',
               'she tells the whole story, twice']),

 dict(key='garden', title='Kebun belakang rumah', latar='trees', pals=['mint', 'sky'],
      furni=['plantbig_olive', 'flowerstand_olive', 'gate_dark'],
      actors=['victim;neighbor', 'grandma;neighbor'],
      props=['phone', 'house'],
      kwsets=[['out in the garden', 'the back yard'],
              ['the tomato plants', 'a call while gardening'],
              ['the garden gate', 'watering the flowers']],
      flavors=['tomato plants in tidy rows',
               'a watering can and a sun hat',
               'the neighbor leans over the fence',
               'a phone buzzing in an apron pocket']),

 dict(key='church', title='Aula komunitas', latar='office', pals=['wood', 'ivory'],
      furni=['pulpit_wood', 'chair_dark'],
      actors=['victim;neighbor'],
      props=['checklist', 'phone'],
      kwsets=[['after the service', 'the church hall'],
              ['the community meeting', 'a warning at the hall'],
              ['the bulletin board', 'a note from the pastor']],
      flavors=['folding chairs and coffee urns',
               'a sign-up sheet by the door',
               'the hall smells like fresh coffee',
               'everyone knows everyone here']),

 dict(key='livingroom', title='Ruang tamu sore hari', latar='home', pals=['ivory', 'wood'],
      furni=['tvstand_wood', 'rug_teal', 'chair_wood'],
      actors=['victim;caller', 'grandma;grandpa'],
      props=['phone', 'monitor'],
      kwsets=[['the evening news', 'the living room'],
              ['in her favorite chair', 'the television was on'],
              ['a quiet evening at home', 'the lamp by the couch']],
      flavors=['the news hums in the background',
               'a blanket over the armchair',
               'family photos on the shelf',
               'the cat jumps down as the phone rings']),

 dict(key='romance', title='Chat romantis tengah malam', latar='home', pals=['dusk', 'blush'],
      furni=['armchair_teal', 'floorlamp_cream', 'wardrobe_navy'],
      actors=['victim;fox', 'victim;viper', 'victim;crow'],
      props=['phone', 'heart', 'v_ring'],
      kwsets=[['a message from a stranger', 'his profile photo'],
              ['two weeks of good mornings', 'a soldier stationed abroad'],
              ['a video call from abroad', 'the flowers she never received']],
      flavors=['the phone glows past midnight',
               'a folder of saved good-morning texts',
               'flowers she bought herself',
               'his profile photo, too perfect']),

 dict(key='joboffer', title='Tawaran kerja dari rumah', latar='office', pals=['terminal', 'clinical'],
      furni=['desk_navy', 'pcdesk_dark', 'bookshelf_cream'],
      actors=['victim;stan', 'victim;amos', 'victim;irs'],
      props=['laptop', 'v_contract', 'checklist'],
      kwsets=[['the job listing', 'work from home'],
              ['the recruiter said', 'an equipment fee'],
              ['a hiring bonus', 'the task of the day']],
      flavors=['a fresh resume, a hopeful morning',
               'the offer arrived within an hour',
               'a title and a salary too good',
               'the contract asks for a fee']),

 dict(key='taskmule', title='Aplikasi tugas / komisi palsu', latar='office', pals=['terminal'],
      furni=['pcdesk_gray', 'chart_up'],
      actors=['victim;tech', 'victim;viper'],
      props=['phone', 'btc', 'v_calendar'],
      kwsets=[['the task app', 'complete orders'],
              ['your commission', 'upgrade to vip'],
              ['boost the store', 'one more task']],
      flavors=['small wins at first, then bigger tasks',
               'a group chat full of fake winners',
               'the balance that cannot withdraw',
               'a mentor who messages at midnight']),

 dict(key='recovery', title='Janji uang kembali', latar='office', pals=['clinical', 'wood'],
      furni=['desk_dark', 'cabinet_gray'],
      actors=['victim;stan', 'victim;amos'],
      props=['v_suitcase', 'report', 'wallet'],
      kwsets=[['the recovery firm', 'we can get your money back'],
              ['a small fee first', 'your case is approved'],
              ['the license number', 'sign here to release']],
      flavors=['hope arrives exactly when it hurts',
               'a letterhead that looks official',
               'they already know her story',
               'the fee grows every week']),

 dict(key='digiarrest', title='Penangkapan digital via video call', latar='office', pals=['terminal'],
      furni=['pcdesk_dark', 'tvset_navy'],
      actors=['victim;crow', 'victim;viper'],
      props=['monitor', 'v_badge', 'clock'],
      kwsets=[['stay on the video call', 'you are under investigation'],
              ['do not hang up', 'the warrant number'],
              ['show us your accounts', 'or you will be arrested']],
      flavors=['the camera light never turns off',
               'hours of fear in a silent room',
               'a badge flashed for one second',
               'the phone may not leave the hand']),

 dict(key='sextortion', title='Email pemerasan', latar='home', pals=['dusk'],
      furni=['tvstand_gray', 'armchair_navy'],
      actors=['victim;fox', 'victim;rex'],
      props=['monitor', 'mail', 'clock'],
      kwsets=[['the email said hello pervert', 'a video of you'],
              ['pay in 24 hours', 'your contacts list'],
              ['a stolen password', 'the threat arrives at breakfast']],
      flavors=['the kitchen is bright, the email is dark',
               'a password from an old breach',
               'no video exists, but the fear is real',
               'delete, block, and breathe']),

 dict(key='charity', title='Donasi palsu', latar='street', pals=['sky', 'ivory'],
      furni=['flowerstand_cream', 'shopcounter_teal'],
      actors=['victim;neighbor', 'victim;vera'],
      props=['heart', 'wallet', 'mail'],
      kwsets=[['the charity caller', 'donate now'],
              ['after the disaster', 'a thank-you gift'],
              ['we help the veterans', 'the pledge line']],
      flavors=['right after the evening news',
               'a cause close to her heart',
               'the caller already knows her name',
               'a receipt that never comes']),

 dict(key='homerepair', title='Kontraktor & atap palsu', latar='street', pals=['sand', 'sky'],
      furni=['picket_gray', 'benchwood_wood'],
      actors=['victim;mechanic', 'victim;hank'],
      props=['house', 'v_ladder', 'v_contract'],
      kwsets=[['the roofer knocked', 'a free inspection'],
              ['one shingle lifted', 'the storm damage'],
              ['the pool that was never built', 'half the money upfront']],
      flavors=['a ladder appears out of nowhere',
               'photos of damage on a stranger phone',
               'the truck has no company name',
               'a handshake instead of a contract']),

 dict(key='timeshare', title='Jual kembali timeshare', latar='office', pals=['wood'],
      furni=['sidetable_cream', 'bookshelf_navy', 'podium_cream'],
      actors=['victim;stan', 'victim;bankmanager'],
      props=['v_contract', 'v_ticket', 'wallet'],
      kwsets=[['the timeshare buyer', 'a resale offer'],
              ['the upfront fee', 'your points are worth'],
              ['a closing date tomorrow', 'the contract expires']],
      flavors=['a resort photo on glossy paper',
               'years of fees in one folder',
               'the buyer is always almost ready',
               'the fee first, the buyer never']),

 dict(key='travel', title='Penerbangan & rental palsu', latar='plain', pals=['terminal'],
      furni=['depboard_teal', 'depseats_navy'],
      actors=['victim;agent', 'victim;teller2'],
      props=['v_ticket', 'phone', 'v_suitcase'],
      kwsets=[['your flight was canceled', 'call this number to rebook'],
              ['a rebooking fee', 'the airline desk'],
              ['the vacation rental', 'the down payment']],
      flavors=['a gate change on a tired screen',
               'suitcases and a dying phone',
               'the real airline never calls first',
               'a listing that vanishes after payment']),

 dict(key='shopping', title='Belanja online tak sampai', latar='plain', pals=['store'],
      furni=['shelfgoods_teal', 'shopcounter_wood', 'locker_navy'],
      actors=['victim;vera', 'victim;sid'],
      props=['v_box', 'card', 'v_umbrella'],
      kwsets=[['the online order', 'it never arrived'],
              ['the tracking link', 'a redelivery fee'],
              ['ninety percent off', 'the checkout looked real']],
      flavors=['a deal that felt like a secret',
               'the tracking stops at the border',
               'the store has no address',
               'reviews that all sound the same']),

 dict(key='debtcollect', title='Penagih utang palsu', latar='office', pals=['clinical'],
      furni=['desk_gray', 'cabinet_navy'],
      actors=['victim;stan', 'victim;earl'],
      props=['report', 'phone', 'v_check'],
      kwsets=[['the debt collector', 'pay today or be sued'],
              ['the case number', 'a wage garnishment'],
              ['a debt you do not know', 'the settlement window']],
      flavors=['a voice that never blinks',
               'papers that look like a court order',
               'the caller knows an old address',
               'validation, in writing, first']),

 dict(key='utility', title='Ancaman putus listrik', latar='home', pals=['ivory', 'sand'],
      furni=['fridge_teal', 'stove_cream'],
      actors=['victim;mechanic', 'victim;hank'],
      props=['phone', 'clock', 'wallet'],
      kwsets=[['the power company', 'your bill is overdue'],
              ['we cut it in an hour', 'pay with a gift card'],
              ['the meter number', 'a reconnection fee']],
      flavors=['the kettle is on, the lights are fine',
               'a storm is coming, says the caller',
               'the bill was paid on Tuesday',
               'a badge number that is not a badge']),

 dict(key='checkwash', title='Cek dicuci dari kotak surat', latar='street', pals=['mint', 'sky'],
      furni=['mailboxbig_red', 'picket_navy'],
      actors=['victim;courier', 'victim;rex'],
      props=['v_check', 'mail', 'wallet'],
      kwsets=[['the check in the mail', 'washed and rewritten'],
              ['a blue pen next time', 'the thief reads your ink'],
              ['the stolen checks', 'a higher amount']],
      flavors=['the mailbox flag, a small red warning',
               'an envelope that feels lighter',
               'the bank calls before she does',
               'ink that dissolves like sugar']),

 dict(key='cryptorom', title='Cinta + investasi kripto palsu', latar='home', pals=['dusk'],
      furni=['armchair_navy', 'tvset_gray'],
      actors=['victim;fox', 'victim;viper'],
      props=['phone', 'btc', 'heart'],
      kwsets=[['he taught her to invest', 'the trading app'],
              ['withdraw your profits', 'one last deposit'],
              ['the graph goes only up', 'a wallet for two']],
      flavors=['love and a candlestick chart',
               'the first withdrawal works, the second never',
               'a future planned in screenshots',
               'the app icon she cannot find again']),

 dict(key='juryduty', title='Ancaman tugas juri', latar='office', pals=['wood'],
      furni=['judgebench_dark', 'podium_navy'],
      actors=['victim;sheriff', 'victim;earl'],
      props=['v_badge', 'report', 'phone'],
      kwsets=[['you missed jury duty', 'the warrant'],
              ['the fine is due today', 'a prepaid card'],
              ['the deputy asked for a code', 'the case number']],
      flavors=['a Monday morning, a threat by noon',
               'the caller provides a badge number',
               'the real court never calls',
               'a warrant that exists only on the phone']),
]

# ---------- builder ----------
_jitter_x = [1250, 1330, 1400, 1470, 1550, 1620]
_jitter_y = [500, 540, 560, 590]


def _swap(left, right, tn):
    """Ganti aktor generik dengan cast BARU vpack, rotasi per template."""
    VPOOL = vpack.NEW_VICTIMS + ['grandma', 'grandpa']
    SPOOL = vpack.NEW_SCAMMERS + ['scammer', 'tech']
    PRO = {'teller': ['teller2', 'banker', 'stan'],
           'banker': ['stan', 'teller2', 'banker'],
           'doctor': ['nora', 'doctor'], 'judge': ['judge', 'stan'],
           'cop': ['earl', 'cop'], 'officer': ['earl', 'officer'],
           'agent': ['amos', 'agent'], 'courier': ['rex', 'courier'],
           'neighbor': ['sid', 'vera', 'doris']}
    if left in ('victim', 'grandma', 'grandpa'):
        left = VPOOL[tn % len(VPOOL)]
    if right in PRO:
        o = PRO[right]
        right = o[tn % len(o)]
    elif right in ('scammer', 'tech', 'caller'):
        right = SPOOL[tn % len(SPOOL)]
    return left, right


def get_template(tn):
    tn = ((int(tn) - 1) % N_TEMPLATES) + 1
    th = THEMES[(tn - 1) % len(THEMES)]
    var = (tn - 1) // len(THEMES)
    con = concept_deck.get_concept(tn)

    left, right = _swap(*th['actors'][var % len(th['actors'])].split(';'), tn)
    mact = con['motion'][1]
    if mact.startswith('victim') and '@' in mact:
        left = left + '@' + mact.split('@')[1]
    elif mact.startswith('scammer') and '@' in mact:
        right = right + '@' + mact.split('@')[1]
    actors = left + ';' + right

    kws = th['kwsets'][var % len(th['kwsets'])]
    flavor = th['flavors'][var % len(th['flavors'])]

    # 2 prop tema (cast) + 1 objek BARU (objpack), animasi ikut konsep
    pool = th['props'][:]
    a0 = con['propm'][1].split(' ')[0]
    props = ['%s:%s:%d,%d,%s' % (pool[(var) % len(pool)], a0,
                                 _jitter_x[(tn * 3) % 6], _jitter_y[(tn * 5) % 4],
                                 round(2.2 + (tn % 5) * 0.2, 1)),
             '%s:%s:%d,%d,%s' % (pool[(var + 1) % len(pool)],
                                 ANIMS[(tn + 1) % 4], _jitter_x[(tn * 3 + 1) % 6],
                                 _jitter_y[(tn * 5 + 1) % 4],
                                 round(2.2 + ((tn + 1) % 5) * 0.2, 1))]
    prop_obj = vpack.OBJ_NEW[(tn * 7) % len(vpack.OBJ_NEW)]
    props.append('%s:%s:%d,%d,%s' % (prop_obj, ANIMS[(tn + 2) % 4],
                                     _jitter_x[(tn * 3 + 2) % 6],
                                     _jitter_y[(tn * 5 + 2) % 4],
                                     round(2.0 + ((tn + 2) % 5) * 0.2, 1)))

    bg_name = 'vk%03d' % tn          # latar BARU, unik per template
    name = 'vt%03d_%s' % (tn, th['key'])
    motif_line = '%s | %s | %s | %s | %s' % (
        name, ','.join(kws), actors, '+'.join(props), bg_name)

    furni_prev = [f[0] for f in vpack.furni_for(tn, th['key'])]

    return dict(id=tn, key=th['key'], title=th['title'], latar=bg_name,
                name=name, keywords=kws, actors=actors, props=' + '.join(props),
                prop_obj=prop_obj, bg=bg_name, bg_file=bg_name,
                palette=th['pals'][var % len(th['pals'])],
                furni=furni_prev, flavor=flavor, motif_line=motif_line,
                concept=dict(alur=con['alur'][0], gerak=con['motion'][0],
                             camera=con['camera'][0], staging=con['staging'][0],
                             propm=con['propm'][0]))


def visual_block(tn):
    t = get_template(tn)
    lines = [
        '=== VISUAL TEMPLATE VT-%03d - "%s" (follow strictly) ===' % (t['id'], t['title']),
        'This episode must LOOK different from every other episode. Weave each of these',
        'short phrases naturally into the narration, each exactly ONCE, in three DIFFERENT',
        'paragraphs (do not cluster them together):']
    lines += ['  - "%s"' % k for k in t['keywords']]
    lines += [
        'Scene flavor for those moments: %s.' % t['flavor'],
        'Do not add stage directions, brackets, or labels; the phrases alone are enough.']
    return '\n'.join(lines)


# ---------- preview (komposit aset asli) ----------
def build_preview(tn, out_path):
    from PIL import Image, ImageDraw
    import bgpack
    t = get_template(tn)
    W, H = 640, 360
    img = bgpack.render(t['bg']).convert('RGBA').resize((W, H))
    xs = [30, 250, 440]
    for i, f in enumerate(t['furni'][:3]):
        p = os.path.join(ASSETS, 'furnipack', f + '.png')
        if not os.path.exists(p):
            continue
        sp = Image.open(p).convert('RGBA')
        th = int(H * (0.58 if i == 0 else 0.42))
        ratio = th / sp.height
        sp = sp.resize((max(1, int(sp.width * ratio)), th), Image.LANCZOS)
        x = min(xs[i], W - sp.width - 4)
        img.alpha_composite(sp, (x, H - th - 6))
    try:
        import cast
        sp = cast.prop(t['prop_obj'])
        thh = int(H * 0.30)
        ratio = thh / sp.height
        sp = sp.resize((max(1, int(sp.width * ratio)), thh), Image.LANCZOS)
        img.alpha_composite(sp, (W - sp.width - 10, H - thh - 46))
    except Exception:
        pass
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, 34], fill=(18, 39, 90, 235))
    d.text((10, 9), 'VT-%03d - %s [alur %s / gerak %s]' % (
        t['id'], t['title'], t['concept']['alur'], t['concept']['gerak']),
        fill=(255, 197, 61))
    img.convert('RGB').save(out_path)
    return out_path
